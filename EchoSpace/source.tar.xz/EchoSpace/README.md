# 🎧 EchoSpace — Environments (Android)

A **real native Android app**, not a website or WebView. Explore natural environments, create your own soundscapes by dragging sounds around a 2D acoustic map, and hear spatial stereo effects using ordinary headphones such as the **JBL Tune 510BT**.

## This build includes

- **Five environments:** Rain Chamber, Deep Forest, Night Shore, Fireside, Dream Drift.
- **Nine offline nature and ambient textures:** rain, distant thunder, ocean, wind, fire, chimes, birds, nighttime crickets, and stream.
- **Interactive 2D sound field:** drag each sound source to position it left/right/front/back around the listener.
- **Spatial stereo engine:** level differences (ILD), a short interaural time difference (ITD), approximate front/back darkening, and distance attenuation; smoothly interpolates marker drags.
- **Manual orientation control:** turn the virtual listening direction from -180° to +180° to simulate looking around.
- **Mixer:** per-layer volume, mute, delete, add, master volume.
- **Background playback:** Android media foreground service with notification playback control.
- **15/30/60-minute sleep timer**, saved edits, offline operation, and no login or network permission.

### Important audio limitations

The app currently generates **procedural** audio in real time. These sounds are approximations; they are **not field recordings**. Spatial stereo offers a directional impression, but is **not personalized HRTF**, guaranteed rear/elevation perception, head-tracked 6DoF audio or Dolby Atmos. JBL Tune 510BT does **not** supply motion-tracking orientation to this app. The direction slider is manual. For higher realism, the next stage is replacing/generated layers with licensed high-fidelity looping environment recordings and an actual HRTF processor.

## Build and install an APK

### Option A — Android Studio on your computer

1. Install **Android Studio** with **Android SDK Platform 35** and **JDK 17**.
2. Extract this ZIP. Open the **`EchoSpace`** folder as a Gradle project in Android Studio.
3. Allow Gradle sync; use Android Studio's Gradle setting with **Gradle 8.11.1** if prompted. Dependencies require an internet connection during the first build.
4. Select **Build → Build APK(s)** (or run the Gradle task `assembleDebug`).
5. Install **`app/build/outputs/apk/debug/app-debug.apk`** on your Android phone (Android 8.0+).

The archive intentionally does **not** contain a fabricated or uncompiled APK, nor the Gradle wrapper binary. If running from terminal, use an installed `gradle` command (version 8.11.1) instead of `./gradlew`.

### Option B — GitHub Actions (no Android Studio)

1. Create a GitHub repository for EchoSpace and upload the **contents of this folder**, including `.github/workflows/android-apk.yml`.
2. On the repository **Actions** tab, run **EchoSpace Android debug APK** (or push to `main`).
3. Once the workflow completes, download the `EchoSpace-debug-apk` artifact and extract `app-debug.apk`.
4. Install it on your Android phone. You may need to authorize installation from your file manager.

GitHub Actions builds a **debug-signed** APK. It is suitable for testing, not a production Play Store release.

## Architecture

- `app/src/main/java/com/nexa/echospace/MainActivity.kt` — Compose UI and editable sound field.
- `.../audio/SpatialSynth.kt` — stereo procedural sound textures and spatial processing.
- `.../audio/AudioEngine.kt` — realtime native `AudioTrack` PCM output thread.
- `.../audio/SpatialAudioService.kt` — audio focus, background playback, media notification, sleep timer.
- `.../model/Scene.kt` — sound definitions and preset mixes.
- `.../model/SceneStore.kt` — private persistent edits.
- `app/src/test/.../SpatialSynthTest.kt` — synthesis, pan, mute and rotation tests.
- `tools/RenderPreview.kt` — optional standalone JVM WAV smoke test.

## Test locally

Run `gradle testDebugUnitTest` for unit tests. Run `gradle assembleDebug` to build an APK. Real-time Android playback, notification behavior, Bluetooth output, and lifecycle must also be tested on a physical device.

## Privacy

No analytics, ads, accounts, servers, tracking, recording, or internet access. An optional Android notification permission is requested for playback notifications on newer devices. All scene settings are stored privately on-device.

## Version

Native Android / Kotlin + Jetpack Compose. Version `0.1.0` — first functional prototype. Real-device build and audio playback are not yet verified in this chat environment.
