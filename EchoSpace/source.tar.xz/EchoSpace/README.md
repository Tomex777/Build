# 🎧 EchoSpace — Environments (Android)

A **real native Android app**, not a website or WebView. Explore natural environments, create your own soundscapes by dragging sounds around a 2D acoustic map, and hear spatial stereo effects using ordinary headphones such as the **JBL Tune 510BT**.

## Tested Android interface

The native UI uses Dark Immersive + Aurora and subtle translucent glass controls, tested on Android emulators: the environment selector, interactive sound map, selected-layer controls and pinned play/volume bar are the primary surfaces. The intro slogans, redundant badges, repeated hints and long footers were removed. See `QA_REPORT.md` for emulator results and remaining physical-device tests.

## This build includes

- **Five environments:** Rain Chamber, Deep Forest, Night Shore, Fireside, Dream Drift.
- **Nine offline nature and ambient textures:** rain, distant thunder, ocean, wind, fire, chimes, birds, nighttime crickets, and stream.
- **Interactive 2D sound field:** drag each sound source to position it left/right/front/back around the listener.
- **Spatial stereo engine:** level differences (ILD), a short interaural time difference (ITD), approximate front/back darkening, and distance attenuation; smoothly interpolates marker drags.
- **Manual orientation control:** turn the virtual listening direction from -180° to +180° to simulate looking around.
- **Mixer:** per-layer volume, mute, delete, add, master volume.
- **Background playback:** Android media foreground service with notification playback control.
- **15/30/60-minute sleep timer**, saved edits, offline operation, and no login or network permission.

### Important audio limitations

The app currently generates **procedural** audio in real time. These sounds are approximations; they are **not field recordings**. Spatial stereo offers a directional impression, but is **not personalized HRTF**, guaranteed rear/elevation perception, head-tracked 6DoF audio or Dolby Atmos. JBL Tune 510BT does **not** supply motion-tracking orientation to this app. The direction slider is manual. For higher realism, the next stage is replacing/generated layers with licensed high-fidelity looping environment recordings and an actual HRTF processor.

## Build and install an APK

### Option A — Android Studio on your computer

1. Install **Android Studio** with **Android SDK Platform 35** and **JDK 17**.
2. Extract this ZIP. Open the **`EchoSpace`** folder as a Gradle project in Android Studio.
3. Allow Gradle sync; use Android Studio's Gradle setting with **Gradle 8.11.1** if prompted. Dependencies require an internet connection during the first build.
4. Select **Build → Build APK(s)** (or run the Gradle task `assembleDebug`).
5. Install **`app/build/outputs/apk/debug/app-debug.apk`** on your Android phone (Android 8.0+).

The archive intentionally does **not** contain a fabricated or uncompiled APK, nor the Gradle wrapper binary. If running from terminal, use an installed `gradle` command (version 8.11.1) instead of `./gradlew`.

### Option B — GitHub Actions (no Android Studio)

1. Create a GitHub repository for EchoSpace and upload the **contents of this folder**, including `.github/workflows/android-apk.yml`.
2. On the repository **Actions** tab, run **EchoSpace Android debug APK** (or push to `main`).
3. Once the workflow completes, download the `EchoSpace-debug-apk` artifact and extract `app-debug.apk`.
4. Install it on your Android phone. You may need to authorize installation from your file manager.

GitHub Actions builds a **debug-signed** APK. It is suitable for testing, not a production Play Store release.

## Architecture

- `app/src/main/java/com/nexa/echospace/MainActivity.kt` — Compose UI and editable sound field.
- `.../audio/SpatialSynth.kt` — stereo procedural sound textures and spatial processing.
- `.../audio/AudioEngine.kt` — realtime native `AudioTrack` PCM output thread.
- `.../audio/SpatialAudioService.kt` — audio focus, background playback, media notification, sleep timer.
- `.../model/Scene.kt` — sound definitions and preset mixes.
- `.../model/SceneStore.kt` — private persistent edits.
- `app/src/test/.../SpatialSynthTest.kt` — synthesis, pan, mute and rotation tests.
- `tools/RenderPreview.kt` — optional standalone JVM WAV smoke test.

## Test locally

Run `gradle testDebugUnitTest` for unit tests. Run `gradle assembleDebug` to build an APK. Real-time Android playback, notification behavior, Bluetooth output, and lifecycle still need physical-device testing; a Pixel 6 emulator UI smoke test has passed.

## Privacy

No analytics, ads, accounts, servers, tracking, recording, or internet access. An optional Android notification permission is requested for playback notifications on newer devices. All scene settings are stored privately on-device.

## Version

Native Android / Kotlin + Jetpack Compose. Version `0.3.1` — environment crossfades, saved My Space mix and immersive native design. Real-device build and audio playback are not yet verified in this chat environment.

## v0.3.0 — smoother environment switching

- Preset switching, muting, and deleting now fade outgoing layers over 420ms instead of abruptly stopping sound.
- Bookmark button beside Environments saves your current layout as **My Space**; revisit it from the environment row even after restarting the app.
- Removed repetitive text from the playback dock. All playback remains offline, native, and background-capable.

- New sounds now seek open positions on the spatial map to avoid overlapping existing markers.

## v0.4 visual direction

Immersive photography replaces the generated silhouette backdrop; all five preset scene photos ship offline. The Explore carousel uses photographic cards. The master volume slider is removed intentionally; use the phone's volume keys. A single thick mixer control affects only the selected sound layer. The heading control uses optional 30° step buttons.


## EchoSpace v0.5 audio upgrade

The offline audio pack is built using `python3 tools/prepare_audio.py` (requires Internet *only* during production build and installed `ffmpeg`). It downloads 16 individually confirmed Freesound CC0 recordings and MIT-measured KEMAR impulse responses (0,90,180 degree positions). Assets are stored in the APK and need no network permission. The headphone renderer spatializes each source with measured binaural filters and interactive placement, instead of relying only on ILD/ITD panning. Manual orientation remains available for non-tracked stereo headphones. Select **Living** to hear evolving scenes or **Steady** to hold the layer balance. The recording provenance and measurement limitations are documented in `AUDIO_CREDITS.md`.
