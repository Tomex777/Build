# EchoSpace QA

## Version 0.2.0 — Dark Immersive + Aurora

- Fully native Jetpack Compose surface, environmental aurora gradients and scene silhouettes drawn live by Canvas.
- Animated breathing listener beacon and slow atmospheric motion.
- Sound map remains fully draggable; source mixer, mute, remove, add and scenes remain operational.
- Preset-driven color palettes: storm / forest / ocean / fireside / dreams.
- Minimal glass panels and always-available playback dock with master volume.

Android build / emulator verification is tracked by the `EchoSpace Android emulator QA` workflow in the `Tomex777/Build` repository, branch `feature/echospace-emulator-qa`.

Physical Bluetooth headphone listening and true binaural HRTF accuracy are not automatically verifiable in the emulator. The app continues to use synthetic stereo spatial audio, not hardware head tracking.
