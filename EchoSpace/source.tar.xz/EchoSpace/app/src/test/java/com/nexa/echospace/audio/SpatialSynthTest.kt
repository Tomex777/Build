package com.nexa.echospace.audio

import com.nexa.echospace.model.Scenes
import com.nexa.echospace.model.SoundPlacement
import com.nexa.echospace.model.SoundKind
import com.nexa.echospace.model.SoundSource
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

class SpatialSynthTest {
    @Test fun `all presets produce audible stereo output`() {
        Scenes.presets.forEach { scene ->
            val synth = SpatialSynth()
            val pcm = ShortArray(8192)
            synth.renderInto(pcm, scene.sources, 0.8f)
            assertTrue("${scene.title} should not be silent", pcm.any { it.toInt() != 0 })
        }
    }

    @Test fun `left source biases left stereo channel`() {
        val synth = SpatialSynth()
        val pcm = ShortArray(32768)
        synth.renderInto(pcm, listOf(SoundSource(42, SoundKind.CHIMES, -0.9f, 0f)), 0.7f)
        val left = pcm.indices.step(2).sumOf { abs(pcm[it].toInt()).toLong() }
        val right = pcm.indices.step(2).sumOf { abs(pcm[it + 1].toInt()).toLong() }
        assertTrue("Pan should favor left", left > right * 1.4)
    }

    @Test fun `turning around swaps left and right`() {
        val source = listOf(SoundSource(33, SoundKind.CHIMES, -0.85f, 0f))
        val original = ShortArray(32768)
        val turned = ShortArray(32768)
        SpatialSynth().renderInto(original, source, 0.8f, 0f)
        SpatialSynth().renderInto(turned, source, 0.8f, 180f)
        fun sum(pcm: ShortArray, offset: Int): Long =
            (offset until pcm.size step 2).sumOf { abs(pcm[it].toInt()).toLong() }
        assertTrue(sum(original, 0) > sum(original, 1))
        assertTrue(sum(turned, 0) < sum(turned, 1))
    }

    @Test fun `removed layers fade naturally instead of cutting instantly`() {
        val synth = SpatialSynth()
        val audible = listOf(SoundSource(9, SoundKind.CHIMES, -0.65f, 0.1f))
        val pcm = ShortArray(4096)
        repeat(6) { synth.renderInto(pcm, audible, 0.7f) }
        synth.renderInto(pcm, emptyList(), 0.7f)
        assertTrue("removed sound should have a short audio tail", pcm.any { it != 0.toShort() })
        repeat(35) { synth.renderInto(pcm, emptyList(), 0.7f) }
        assertTrue("removed sound must eventually become silent", pcm.all { it == 0.toShort() })
    }

    @Test fun `rapid environment switching produces finite bounded audio`() {
        val synth = SpatialSynth()
        val pcm = ShortArray(2048)
        repeat(40) { i ->
            synth.renderInto(pcm, Scenes.presets[i % Scenes.presets.size].sources, 0.9f)
            assertTrue(pcm.all { it.toInt() in -32768..32767 })
        }
    }

    @Test fun `newly added sound avoids existing map markers`() {
        val scene = Scenes.forest.sources
        val (x, y) = SoundPlacement.next(scene)
        assertTrue("new layer should not overlap forest layers",
            scene.all { kotlin.math.hypot(it.x - x, it.y - y) > 0.30f })
        assertTrue("new layer must be inside listening circle", kotlin.math.hypot(x, y) <= 0.98f)
    }

    @Test fun `muting all sources outputs silence`() {
        val synth = SpatialSynth()
        val pcm = ShortArray(4096)
        val scene = Scenes.forest.sources.map { it.copy(muted = true) }
        synth.renderInto(pcm, scene, 1f)
        assertTrue(pcm.all { it.toInt() == 0 })
    }
}
