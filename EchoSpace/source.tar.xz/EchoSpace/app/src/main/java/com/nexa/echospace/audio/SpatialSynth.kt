package com.nexa.echospace.audio

import com.nexa.echospace.model.SoundKind
import com.nexa.echospace.model.SoundSource
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Nine completely offline procedural environmental textures, with headphone stereo
 * spatialization using level difference, interaural time delay and approximate
 * front/back tone filtering. Sound positions stay fixed while heading changes.
 *
 * This is NOT a personalized HRTF or sensor-based head tracking. The recordings
 * are synthesized, so natural environments are approximations rather than field recordings.
 */
class SpatialSynth(private val sampleRate: Int = 44_100) {
    private val voices = mutableMapOf<Int, Voice>()
    private val twoPi = 2.0 * PI

    fun renderInto(
        out: ShortArray,
        sources: List<SoundSource>,
        masterGain: Float,
        headingDegrees: Float = 0f
    ) {
        require(out.size % 2 == 0) { "Stereo output requires an even buffer length" }
        val active = sources.filterNot { it.muted || it.gain <= 0f }.take(16)
        val ids = sources.map { it.id }.toSet()
        voices.keys.retainAll(ids)
        active.forEach { source ->
            if (voices[source.id]?.kind != source.kind) {
                voices[source.id] = Voice(source.kind, source.id * 1_013_904_223L + 1L)
            }
        }
        val normalize = 1.45 / sqrt(max(1, active.size).toDouble())
        val gain = masterGain.coerceIn(0f, 1f).toDouble() * normalize
        val angle = headingDegrees.coerceIn(-180f, 180f) * PI / 180.0
        val co = cos(angle)
        val si = sin(angle)

        for (i in out.indices step 2) {
            var left = 0.0
            var right = 0.0
            for (source in active) {
                val v = voices.getValue(source.id)
                val worldX = source.x.coerceIn(-1f, 1f)
                val worldY = source.y.coerceIn(-1f, 1f)
                val targetX = worldX * co + worldY * si
                val targetY = -worldX * si + worldY * co
                // Per-sample smoothing makes marker drags and rotation silent and fluid.
                v.smoothX += (targetX - v.smoothX) * 0.003
                v.smoothY += (targetY - v.smoothY) * 0.003
                v.smoothGain += (source.gain.coerceIn(0f, 1f) - v.smoothGain) * 0.003
                val x = v.smoothX
                val y = v.smoothY
                val distance = hypot(x, y)
                val attenuation = 1.0 / (1.0 + 1.28 * distance)

                val raw = v.nextSample(sampleRate, twoPi)
                // Behind-the-head cues are intentionally subtle, not true HRTF elevation.
                val filter = if (y > 0) 0.13 + (1.0 - y.coerceIn(0.0, 1.0)) * 0.39 else 0.66
                v.toneFilter += (raw - v.toneFilter) * filter
                val mono = v.toneFilter * attenuation * v.smoothGain * gain
                val pan = x.coerceIn(-1.0, 1.0)
                val theta = (pan + 1.0) * PI / 4.0
                val leftGain = cos(theta)
                val rightGain = sin(theta)
                val itd = (abs(pan) * sampleRate * 0.00052).toInt().coerceAtMost(v.delay.size - 2)
                v.delay[v.delayPos] = mono
                val delayed = v.delay[(v.delayPos - itd + v.delay.size) % v.delay.size]
                v.delayPos = (v.delayPos + 1) % v.delay.size
                if (pan >= 0) {
                    left += delayed * leftGain
                    right += mono * rightGain
                } else {
                    left += mono * leftGain
                    right += delayed * rightGain
                }
            }
            // Soft saturation controls unexpectedly dense scenes without hard clipping.
            out[i] = (softClip(left) * 32767.0).toInt().toShort()
            out[i + 1] = (softClip(right) * 32767.0).toInt().toShort()
        }
    }

    private fun softClip(x: Double): Double = (x / (1.0 + abs(x) * 0.32)).coerceIn(-1.0, 1.0)

    private class Voice(val kind: SoundKind, seed: Long) {
        var smoothX = 0.0
        var smoothY = 0.0
        var smoothGain = 0.0
        var toneFilter = 0.0
        var low = 0.0
        var low2 = 0.0
        var high = 0.0
        var event = 0.0
        var phase = 0.0
        var frames = 0L
        var randomState: Long = if (seed == 0L) 1L else seed
        val delay = DoubleArray(64)
        var delayPos = 0

        private fun noise(): Double {
            var x = randomState
            x = x xor (x shl 13)
            x = x xor (x ushr 7)
            x = x xor (x shl 17)
            randomState = x
            return ((x ushr 40).toDouble() / 8_388_608.0) - 1.0
        }

        fun nextSample(sampleRate: Int, twoPi: Double): Double {
            val n = noise()
            val t = frames.toDouble() / sampleRate
            frames++
            return when (kind) {
                SoundKind.RAIN -> {
                    low += (n - low) * 0.027
                    high += (n - low - high) * 0.37
                    if (n > 0.993) event = 1.0
                    event *= 0.94
                    high * 0.72 + event * n * 0.22
                }
                SoundKind.THUNDER -> {
                    low += (n - low) * 0.007
                    low2 += (low - low2) * 0.017
                    val swell = 0.16 + 0.84 * (0.5 + 0.5 * sin(twoPi * t / 12.5)).let { it * it }
                    val bass = sin(twoPi * 39.0 * t) * 0.12 + sin(twoPi * 52.0 * t) * 0.09
                    (low2 * 4.2 + bass) * swell
                }
                SoundKind.OCEAN -> {
                    low += (n - low) * 0.045
                    low2 += (low - low2) * 0.009
                    val swell = 0.12 + 0.88 * (0.5 + 0.5 * sin(twoPi * t / 7.3)).let { it * it }
                    (low2 * 3.0 + low * 1.35 + n * 0.13) * swell
                }
                SoundKind.WIND -> {
                    low += (n - low) * 0.013
                    low2 += (low - low2) * 0.067
                    val gust = 0.14 + 0.86 * (0.5 + 0.5 * sin(twoPi * t / 8.3 + 0.8))
                    (low2 * 3.2 + (n - low) * 0.10) * gust
                }
                SoundKind.FIRE -> {
                    low += (n - low) * 0.052
                    if (n > 0.987) event = 1.0
                    event *= 0.89
                    low * 1.5 + event * (0.5 * n + 0.5) * 0.76
                }
                SoundKind.CHIMES -> {
                    val notes = CHIME_NOTES
                    val duration = 1.85
                    val index = ((t / duration).toInt() % notes.size)
                    val noteAge = t % duration
                    phase += twoPi * notes[index] / sampleRate
                    if (phase >= twoPi) phase -= twoPi
                    val fade = exp(-2.0 * noteAge)
                    (sin(phase) * 0.60 + sin(phase * 2.01) * 0.23 + sin(phase * 3.98) * 0.12) * fade * 0.62
                }
                SoundKind.BIRDS -> {
                    low += (n - low) * 0.026
                    val cycle = t % 3.35
                    val chirpTime = cycle % 0.45
                    val active = if (cycle < 1.7 && chirpTime < 0.22) 1.0 else 0.0
                    val profile = if (active > 0.0) sin(PI * chirpTime / 0.22).let { it * it } else 0.0
                    val hz = 1420.0 + 590.0 * sin(twoPi * chirpTime / 0.24) + 240.0 * sin(twoPi * chirpTime / 0.065)
                    phase += twoPi * hz / sampleRate
                    if (phase >= twoPi) phase -= twoPi
                    sin(phase) * profile * 0.27 + low * 0.42
                }
                SoundKind.NIGHT -> {
                    low += (n - low) * 0.017
                    val cycle = t % 0.78
                    val chirp = if (cycle < 0.31) sin(PI * cycle / 0.31).let { it * it } else 0.0
                    phase += twoPi * (3250.0 + 130.0 * sin(twoPi * t * 15.0)) / sampleRate
                    if (phase >= twoPi) phase -= twoPi
                    (sin(phase) * 0.17 + sin(phase * 1.02) * 0.09) * chirp + low * 0.28
                }
                SoundKind.STREAM -> {
                    low += (n - low) * 0.035
                    low2 += (n - low2) * 0.22
                    val bubbling = 0.76 + 0.24 * sin(twoPi * t / 1.6)
                    if (n > 0.994) event = 1.0
                    event *= 0.96
                    (low * 1.85 + low2 * 0.53 + event * n * 0.16) * bubbling
                }
            }
        }

        companion object {
            private val CHIME_NOTES = doubleArrayOf(261.63, 329.63, 392.0, 523.25, 440.0, 392.0, 329.63, 293.66)
        }
    }
}
