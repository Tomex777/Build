package com.nexa.echospace.model

/** On the sound-field map: negative Y is in front of the listener. */
enum class SoundKind(val title: String, val emoji: String, val subtitle: String) {
    RAIN("Rain", "🌧", "Rainfall"),
    THUNDER("Thunder", "⛈", "Distant rumble"),
    OCEAN("Ocean", "🌊", "Rolling surf"),
    WIND("Wind", "🍃", "Gentle breeze"),
    FIRE("Fire", "🔥", "Crackling embers"),
    CHIMES("Chimes", "✦", "Soft wind chimes"),
    BIRDS("Birdsong", "🐦", "Forest birds"),
    NIGHT("Night life", "🦗", "Crickets at dusk"),
    STREAM("Stream", "💧", "Flowing water")
}

data class SoundSource(
    val id: Int,
    val kind: SoundKind,
    val x: Float,
    val y: Float,
    val gain: Float = 0.8f,
    val muted: Boolean = false
)

data class SoundScene(
    val title: String,
    val emoji: String,
    val caption: String,
    val sources: List<SoundSource>
)

object Scenes {
    val rainChamber = SoundScene("Rain Chamber", "🌧", "A gentle storm", listOf(
        SoundSource(1, SoundKind.RAIN, -0.55f, -0.38f, 0.90f),
        SoundSource(2, SoundKind.THUNDER, 0.83f, -0.38f, 0.45f),
        SoundSource(3, SoundKind.WIND, -0.45f, 0.67f, 0.44f)
    ))
    val forest = SoundScene("Deep Forest", "🌲", "Into the green", listOf(
        SoundSource(1, SoundKind.BIRDS, -0.55f, -0.53f, 0.88f),
        SoundSource(2, SoundKind.STREAM, 0.69f, -0.30f, 0.71f),
        SoundSource(3, SoundKind.WIND, -0.37f, 0.55f, 0.49f)
    ))
    val shore = SoundScene("Night Shore", "🌊", "Tide after dark", listOf(
        SoundSource(1, SoundKind.OCEAN, -0.68f, -0.28f, 0.90f),
        SoundSource(2, SoundKind.WIND, 0.63f, -0.47f, 0.43f),
        SoundSource(3, SoundKind.NIGHT, 0.53f, 0.58f, 0.40f)
    ))
    val fireside = SoundScene("Fireside", "🔥", "Stay a little longer", listOf(
        SoundSource(1, SoundKind.FIRE, 0.32f, -0.21f, 0.85f),
        SoundSource(2, SoundKind.NIGHT, -0.69f, -0.51f, 0.41f),
        SoundSource(3, SoundKind.WIND, -0.58f, 0.61f, 0.30f)
    ))
    val drift = SoundScene("Dream Drift", "✨", "Drift into calm", listOf(
        SoundSource(1, SoundKind.CHIMES, 0.53f, -0.30f, 0.78f),
        SoundSource(2, SoundKind.OCEAN, -0.71f, 0.34f, 0.41f),
        SoundSource(3, SoundKind.WIND, -0.16f, -0.76f, 0.31f)
    ))
    val presets = listOf(rainChamber, forest, shore, fireside, drift)
}
