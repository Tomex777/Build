package com.nexa.echospace.audio

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Binder
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import com.nexa.echospace.MainActivity
import com.nexa.echospace.model.SceneStore
import com.nexa.echospace.model.Scenes
import com.nexa.echospace.model.SoundSource

/** Keeps soundscapes playing with the screen off and displays a media playback notification. */
class SpatialAudioService : Service() {
    inner class LocalBinder : Binder() { fun service(): SpatialAudioService = this@SpatialAudioService }
    private val binder = LocalBinder()
    private lateinit var engine: AudioEngine
    private lateinit var audioManager: AudioManager
    private val handler = Handler(Looper.getMainLooper())
    private var scheduledStop: Runnable? = null
    private var stopAtMs = 0L
    private var playing = false
    private var focusRequest: AudioFocusRequest? = null
    private var sessionVolume = 0.76f
    private var currentSceneTitle = "Your environment"

    private val focusListener = AudioManager.OnAudioFocusChangeListener { change ->
        if (change == AudioManager.AUDIOFOCUS_LOSS ||
            change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) pause()
    }

    override fun onCreate() {
        super.onCreate()
        engine = AudioEngine()
        audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
        val store = SceneStore(this)
        val restored = store.restore()
        currentSceneTitle = restored?.first ?: Scenes.rainChamber.title
        engine.setSources(restored?.second ?: Scenes.rainChamber.sources)
        sessionVolume = store.volume()
        engine.setMasterVolume(sessionVolume)
        engine.setHeading(store.heading())
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Soundscape playback", NotificationManager.IMPORTANCE_LOW)
        )
    }

    override fun onBind(intent: Intent?): IBinder = binder

    fun updateAudio(title: String, sources: List<SoundSource>, volume: Float, heading: Float) {
        val titleChanged = currentSceneTitle != title
        currentSceneTitle = title
        sessionVolume = volume.coerceIn(0f, 1f)
        engine.setSources(sources)
        engine.setMasterVolume(sessionVolume)
        engine.setHeading(heading)
        // Dragging a marker updates the audio instantly. Rebuilding the Android
        // notification on every drag event causes needless main-thread work.
        if (playing && titleChanged) notificationManager().notify(NOTIFICATION_ID, notification())
    }

    fun isPlaying(): Boolean = playing
    fun error(): String? = engine.failure
    fun remainingSeconds(): Long = if (stopAtMs == 0L) 0L else
        ((stopAtMs - System.currentTimeMillis() + 999L) / 1000L).coerceAtLeast(0L)

    fun setSleepTimer(minutes: Int) {
        scheduledStop?.let(handler::removeCallbacks)
        scheduledStop = null
        stopAtMs = 0L
        if (minutes > 0) {
            stopAtMs = System.currentTimeMillis() + minutes.toLong() * 60_000L
            val task = Runnable { stopAtMs = 0L; scheduledStop = null; pause() }
            scheduledStop = task
            handler.postDelayed(task, minutes.toLong() * 60_000L)
        }
        if (playing) notificationManager().notify(NOTIFICATION_ID, notification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PLAY -> play()
            ACTION_PAUSE, ACTION_STOP -> pause()
        }
        return START_NOT_STICKY
    }

    private fun requestFocus(): Boolean {
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build()
        val request = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(attrs)
            .setOnAudioFocusChangeListener(focusListener)
            .build()
        focusRequest = request
        return audioManager.requestAudioFocus(request) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
    }

    private fun play() {
        // A foreground service must enter foreground promptly after startForegroundService().
        startForeground(NOTIFICATION_ID, notification())
        if (!playing) {
            if (!requestFocus()) {
                pause()
                return
            }
            playing = true
            engine.setPlaying(true)
        }
        notificationManager().notify(NOTIFICATION_ID, notification())
    }

    private fun pause() {
        playing = false
        engine.setPlaying(false)
        focusRequest?.let(audioManager::abandonAudioFocusRequest)
        focusRequest = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun notificationManager(): NotificationManager =
        getSystemService(NOTIFICATION_SERVICE) as NotificationManager

    private fun notification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val toggleAction = if (playing) ACTION_PAUSE else ACTION_PLAY
        val toggle = PendingIntent.getService(
            this, 1, Intent(this, SpatialAudioService::class.java).setAction(toggleAction),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val detail = if (stopAtMs > 0) "Sleep timer active • Stereo headphones recommended"
            else "Spatial soundscape • Offline"
        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("EchoSpace · $currentSceneTitle")
            .setContentText(detail)
            .setContentIntent(open)
            .setOnlyAlertOnce(true)
            .setOngoing(playing)
            .addAction(Notification.Action.Builder(
                android.R.drawable.ic_media_pause,
                if (playing) "Pause" else "Play",
                toggle
            ).build())
            .build()
    }

    override fun onDestroy() {
        scheduledStop?.let(handler::removeCallbacks)
        engine.close()
        focusRequest?.let(audioManager::abandonAudioFocusRequest)
        super.onDestroy()
    }

    companion object {
        const val ACTION_PLAY = "com.nexa.echospace.PLAY"
        const val ACTION_PAUSE = "com.nexa.echospace.PAUSE"
        const val ACTION_STOP = "com.nexa.echospace.STOP"
        private const val CHANNEL_ID = "echospace_playback"
        private const val NOTIFICATION_ID = 510
    }
}
