@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.nexa.echospace

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nexa.echospace.audio.SpatialAudioService
import com.nexa.echospace.model.SceneStore
import com.nexa.echospace.model.Scenes
import com.nexa.echospace.model.SoundKind
import com.nexa.echospace.model.SoundScene
import com.nexa.echospace.model.SoundSource
import kotlinx.coroutines.delay
import kotlin.math.hypot
import kotlin.math.roundToInt
import kotlin.math.sin

private val ink = Color(0xFF050911)
private val white = Color(0xFFF3F7F7)
private val secondary = Color(0xFFA6B8C1)
private val hairline = Color.White.copy(alpha = 0.12f)
private val frosted = Color(0xFF182532).copy(alpha = 0.91f)

private data class Atmosphere(val glow: Color, val light: Color, val deep: Color)
private fun atmosphere(title: String): Atmosphere = when (title) {
    "Deep Forest" -> Atmosphere(Color(0xFF5FD6AC), Color(0xFF2F8D8C), Color(0xFF0C2729))
    "Night Shore" -> Atmosphere(Color(0xFF73CBED), Color(0xFF4165B9), Color(0xFF102547))
    "Fireside" -> Atmosphere(Color(0xFFFFBD7D), Color(0xFFC76B61), Color(0xFF35202E))
    "Dream Drift" -> Atmosphere(Color(0xFFC4B1FF), Color(0xFF8C74D8), Color(0xFF28264D))
    else -> Atmosphere(Color(0xFF87DECE), Color(0xFF4D87B4), Color(0xFF192C4A))
}

class MainActivity : ComponentActivity() {
    private var service by mutableStateOf<SpatialAudioService?>(null)
    private var bound = false
    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            service = (binder as? SpatialAudioService.LocalBinder)?.service()
        }
        override fun onServiceDisconnected(name: ComponentName?) { service = null }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(5, 9, 17)
        window.navigationBarColor = android.graphics.Color.rgb(5, 9, 17)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Color(0xFF97E8D1), onPrimary = ink,
                background = ink, surface = Color(0xFF15232F),
                onSurface = white, onBackground = white
            )) {
                EchoSpaceScreen(service) { action ->
                    if (action == SpatialAudioService.ACTION_PLAY && Build.VERSION.SDK_INT >= 33 &&
                        checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                    ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 51)
                    val command = Intent(this, SpatialAudioService::class.java).setAction(action)
                    if (action == SpatialAudioService.ACTION_PLAY) startForegroundService(command)
                    else startService(command)
                }
            }
        }
    }
    override fun onStart() {
        super.onStart()
        bound = bindService(Intent(this, SpatialAudioService::class.java), connection, Context.BIND_AUTO_CREATE)
    }
    override fun onStop() {
        if (bound) { unbindService(connection); bound = false }
        service = null
        super.onStop()
    }
}

@Composable
private fun EchoSpaceScreen(service: SpatialAudioService?, dispatch: (String) -> Unit) {
    val context = LocalContext.current
    val store = remember { SceneStore(context.applicationContext) }
    val restored = remember { store.restore() }
    var title by remember { mutableStateOf(restored?.first ?: Scenes.rainChamber.title) }
    var sources by remember { mutableStateOf(restored?.second ?: Scenes.rainChamber.sources) }
    var selectedId by remember { mutableIntStateOf(sources.firstOrNull()?.id ?: -1) }
    var volume by remember { mutableFloatStateOf(store.volume()) }
    var heading by remember { mutableFloatStateOf(store.heading()) }
    var isPlaying by remember { mutableStateOf(false) }
    var timerSeconds by remember { mutableLongStateOf(0L) }
    var timerOpen by remember { mutableStateOf(false) }
    var addOpen by remember { mutableStateOf(false) }
    var directionOpen by remember { mutableStateOf(false) }
    val selected = sources.firstOrNull { it.id == selectedId }
    val palette = atmosphere(title)
    val glow by animateColorAsState(palette.glow, animationSpec = tween(850), label = "scene glow")
    val light by animateColorAsState(palette.light, animationSpec = tween(850), label = "scene light")
    val deep by animateColorAsState(palette.deep, animationSpec = tween(850), label = "scene background")
    val motion = rememberInfiniteTransition(label = "ambient movement")
    val drift by motion.animateFloat(0f, 1f, infiniteRepeatable(tween(18000), RepeatMode.Reverse), label = "aurora drift")
    val breathe by motion.animateFloat(0f, 1f, infiniteRepeatable(tween(3800), RepeatMode.Reverse), label = "listener breath")

    LaunchedEffect(title, sources, volume, heading, service) {
        service?.updateAudio(title, sources, volume, heading)
        delay(350)
        store.save(title, sources, volume, heading)
    }
    LaunchedEffect(service) {
        while (true) {
            isPlaying = service?.isPlaying() == true
            timerSeconds = service?.remainingSeconds() ?: 0L
            delay(350)
        }
    }
    fun editSource(id: Int, change: (SoundSource) -> SoundSource) {
        sources = sources.map { if (it.id == id) change(it) else it }
    }
    fun setWorld(scene: SoundScene) {
        title = scene.title
        sources = scene.sources
        selectedId = sources.firstOrNull()?.id ?: -1
        heading = 0f
        directionOpen = false
    }

    Scaffold(containerColor = ink, contentWindowInsets = WindowInsets(0, 0, 0, 0),
        bottomBar = {
            PlaybackDock(isPlaying = isPlaying, enabled = service != null,
                volume = volume, onVolume = { volume = it }, glow = glow,
                onPlay = {
                    service?.updateAudio(title, sources, volume, heading)
                    dispatch(if (isPlaying) SpatialAudioService.ACTION_PAUSE else SpatialAudioService.ACTION_PLAY)
                    isPlaying = !isPlaying
                })
        }
    ) { pad ->
        Column(Modifier.fillMaxSize().background(ink).padding(pad).statusBarsPadding()
            .verticalScroll(rememberScrollState()).padding(horizontal = 18.dp)) {
            Row(Modifier.fillMaxWidth().padding(top = 13.dp, bottom = 17.dp),
                verticalAlignment = Alignment.CenterVertically) {
                BrandMark(glow)
                Spacer(Modifier.width(10.dp))
                Text("EchoSpace", color = white, fontSize = 22.sp,
                    fontWeight = FontWeight.SemiBold, letterSpacing = (-0.8).sp,
                    modifier = Modifier.weight(1f))
                Box {
                    IconButton(onClick = { timerOpen = true },
                        modifier = Modifier.size(46.dp).clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.055f))) {
                        Icon(Icons.Default.Timer, "Sleep timer", tint = if (timerSeconds > 0) glow else secondary)
                    }
                    DropdownMenu(expanded = timerOpen, onDismissRequest = { timerOpen = false },
                        containerColor = Color(0xFF1A2832)) {
                        listOf(0, 15, 30, 60).forEach { minutes ->
                            DropdownMenuItem(text = { Text(if (minutes == 0) "Timer off" else "$minutes minutes") },
                                onClick = { service?.setSleepTimer(minutes); timerOpen = false })
                        }
                    }
                }
            }

            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(31.dp))) {
                AuroraBackdrop(title, glow, light, deep, drift,
                    Modifier.matchParentSize())
                Box(Modifier.matchParentSize().border(1.dp, hairline, RoundedCornerShape(31.dp)))
                Column(Modifier.fillMaxWidth().padding(start = 18.dp, end = 18.dp, top = 23.dp, bottom = 12.dp)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(title, color = white, fontSize = 27.sp,
                                letterSpacing = (-0.7).sp, fontWeight = FontWeight.SemiBold,
                                maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(Scenes.presets.find { it.title == title }?.caption ?: "Your soundscape",
                                color = Color(0xFFBED0D7), fontSize = 12.sp)
                        }
                        IconButton(onClick = { addOpen = true }, enabled = sources.size < 12,
                            modifier = Modifier.size(48.dp).clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.12f))
                                .border(1.dp, hairline, CircleShape)) {
                            Icon(Icons.Default.Add, "Add a sound", tint = white)
                        }
                    }
                    Spacer(Modifier.height(5.dp))
                    SoundMap(sources, selectedId, heading, glow, isPlaying, breathe,
                        onSelect = { selectedId = it },
                        onMove = { id, dx, dy ->
                            editSource(id) { sound ->
                                val x = (sound.x + dx).coerceIn(-1f, 1f)
                                val y = (sound.y + dy).coerceIn(-1f, 1f)
                                val len = hypot(x, y)
                                if (len > 0.98f) sound.copy(x = x * 0.98f / len, y = y * 0.98f / len)
                                else sound.copy(x = x, y = y)
                            }
                        })
                    Row(Modifier.fillMaxWidth().height(32.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("SOUND FIELD", color = Color(0xFFA9C0C6), fontSize = 10.sp,
                            letterSpacing = 1.6.sp, modifier = Modifier.weight(1f))
                        TextButton(onClick = { directionOpen = !directionOpen },
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp)) {
                            Text("↻  ${heading.roundToInt()}°", color = glow, fontSize = 12.sp)
                        }
                    }
                }
            }
            if (directionOpen) {
                GlassPanel(Modifier.fillMaxWidth().padding(top = 9.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Slider(value = heading, onValueChange = { heading = it },
                            valueRange = -180f..180f, modifier = Modifier.weight(1f),
                            colors = ambienceSlider(glow))
                        TextButton(onClick = { heading = 0f }) { Text("Reset", color = glow) }
                    }
                }
            }

            Spacer(Modifier.height(21.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Environments", color = white, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.weight(1f))
                Text("${Scenes.presets.indexOfFirst { it.title == title }.coerceAtLeast(0) + 1} / ${Scenes.presets.size}",
                    color = secondary, fontSize = 12.sp)
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                Scenes.presets.forEach { scene ->
                    SceneTile(scene, chosen = scene.title == title, onClick = { setWorld(scene) })
                }
            }
            Spacer(Modifier.height(17.dp))
            if (selected != null) {
                SelectedSound(selected, glow,
                    onGain = { gain -> editSource(selected.id) { it.copy(gain = gain) } },
                    onMute = { editSource(selected.id) { it.copy(muted = !it.muted) } },
                    onDelete = {
                        sources = sources.filterNot { it.id == selected.id }
                        selectedId = sources.firstOrNull()?.id ?: -1
                    })
            } else {
                GlassPanel(Modifier.fillMaxWidth()) {
                    TextButton(onClick = { addOpen = true }) {
                        Text("+  Add your first sound", color = glow)
                    }
                }
            }
            service?.error()?.let { Text("Playback error: $it", color = Color(0xFFFFA8A7), fontSize = 12.sp,
                modifier = Modifier.padding(top = 10.dp)) }
            Spacer(Modifier.height(17.dp))
        }
    }

    if (addOpen) {
        ModalBottomSheet(onDismissRequest = { addOpen = false }, containerColor = Color(0xFF111D29),
            contentColor = white, dragHandle = { BottomSheetDefaults.DragHandle(color = Color(0xFF667D8C)) }) {
            Row(Modifier.fillMaxWidth().padding(start = 23.dp, end = 13.dp, bottom = 12.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Text("Add a sound", color = white, fontSize = 21.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f))
                IconButton(onClick = { addOpen = false }) { Icon(Icons.Default.Close, "Close", tint = secondary) }
            }
            Column(Modifier.heightIn(max = 450.dp).verticalScroll(rememberScrollState())) {
                SoundKind.entries.forEach { kind ->
                    Row(Modifier.fillMaxWidth().clickable {
                        val id = (sources.maxOfOrNull { it.id } ?: 0) + 1
                        sources = sources + SoundSource(id, kind,
                            if (id % 2 == 0) 0.55f else -0.55f, -0.35f)
                        selectedId = id
                        addOpen = false
                    }.padding(horizontal = 24.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(46.dp).clip(RoundedCornerShape(16.dp))
                            .background(glow.copy(alpha = 0.12f)), contentAlignment = Alignment.Center) {
                            Text(kind.emoji, fontSize = 23.sp)
                        }
                        Spacer(Modifier.width(14.dp))
                        Column {
                            Text(kind.title, fontSize = 15.sp, color = white, fontWeight = FontWeight.Medium)
                            Text(kind.subtitle, fontSize = 12.sp, color = secondary)
                        }
                    }
                }
            }
            Spacer(Modifier.navigationBarsPadding().height(8.dp))
        }
    }
}

@Composable
private fun BrandMark(tint: Color) {
    Canvas(Modifier.size(27.dp)) {
        drawCircle(tint.copy(alpha = 0.2f), radius = size.minDimension * 0.48f)
        drawCircle(tint.copy(alpha = 0.75f), radius = size.minDimension * 0.34f, style = Stroke(1.5.dp.toPx()))
        drawCircle(tint, radius = size.minDimension * 0.12f)
    }
}

@Composable
private fun GlassPanel(modifier: Modifier = Modifier, content: @Composable RowScope.() -> Unit) {
    Row(modifier.clip(RoundedCornerShape(23.dp))
        .background(frosted)
        .border(1.dp, hairline, RoundedCornerShape(23.dp))
        .padding(horizontal = 13.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically, content = content)
}

@Composable
private fun SceneTile(scene: SoundScene, chosen: Boolean, onClick: () -> Unit) {
    val tint = atmosphere(scene.title).glow
    Column(Modifier.width(110.dp).height(93.dp)
        .clip(RoundedCornerShape(19.dp))
        .background(if (chosen) tint.copy(alpha = 0.14f) else Color(0xFF101B27))
        .border(1.dp, if (chosen) tint.copy(alpha = 0.76f) else hairline, RoundedCornerShape(19.dp))
        .clickable(onClick = onClick)
        .padding(horizontal = 13.dp, vertical = 10.dp), verticalArrangement = Arrangement.SpaceBetween) {
        Text(scene.emoji, fontSize = 25.sp)
        Text(scene.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp,
            color = if (chosen) white else Color(0xFFC3CED3), fontWeight = if (chosen) FontWeight.SemiBold else FontWeight.Normal)
    }
}

@Composable
private fun SelectedSound(source: SoundSource, tint: Color,
                          onGain: (Float) -> Unit, onMute: () -> Unit, onDelete: () -> Unit) {
    GlassPanel(Modifier.fillMaxWidth()) {
        Box(Modifier.size(39.dp).clip(RoundedCornerShape(13.dp))
            .background(tint.copy(alpha = 0.15f)), contentAlignment = Alignment.Center) {
            Text(source.kind.emoji, fontSize = 21.sp)
        }
        Spacer(Modifier.width(9.dp))
        Column(Modifier.width(75.dp)) {
            Text(source.kind.title, color = white, fontSize = 12.sp, fontWeight = FontWeight.Medium,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(if (source.muted) "Muted" else "Layer", color = secondary, fontSize = 10.sp)
        }
        Slider(value = source.gain, onValueChange = onGain, modifier = Modifier.weight(1f),
            colors = ambienceSlider(tint))
        IconButton(onClick = onMute, modifier = Modifier.size(38.dp)) {
            Icon(if (source.muted) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                if (source.muted) "Unmute ${source.kind.title}" else "Mute ${source.kind.title}",
                tint = if (source.muted) secondary else tint, modifier = Modifier.size(19.dp))
        }
        IconButton(onClick = onDelete, modifier = Modifier.size(38.dp)) {
            Icon(Icons.Default.DeleteOutline, "Remove ${source.kind.title}",
                tint = Color(0xFFE4A7A9), modifier = Modifier.size(19.dp))
        }
    }
}

@Composable
private fun ambienceSlider(tint: Color) = SliderDefaults.colors(thumbColor = tint,
    activeTrackColor = tint.copy(alpha = 0.9f), inactiveTrackColor = Color(0xFF3C525A))

@Composable
private fun PlaybackDock(isPlaying: Boolean, enabled: Boolean, volume: Float,
                         onVolume: (Float) -> Unit, glow: Color, onPlay: () -> Unit) {
    Column(Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(
        ink.copy(alpha = 0.83f), ink, ink))).navigationBarsPadding()
        .padding(start = 18.dp, end = 18.dp, top = 7.dp, bottom = 6.dp)) {
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(25.dp))
            .background(Color(0xFF192733))
            .border(1.dp, hairline, RoundedCornerShape(25.dp))
            .padding(start = 10.dp, end = 14.dp, top = 10.dp, bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onPlay, enabled = enabled,
                modifier = Modifier.size(55.dp).clip(CircleShape)
                    .background(glow)) {
                Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                    if (isPlaying) "Pause" else "Play", tint = ink, modifier = Modifier.size(29.dp))
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(if (isPlaying) "Listening" else "Ready to listen", color = white,
                    fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(3.dp))
                Text(if (isPlaying) "Ambient sound is playing" else "Tap play to enter the soundscape",
                    color = secondary, fontSize = 11.sp, maxLines = 1,
                    overflow = TextOverflow.Ellipsis)
            }
            Icon(Icons.Default.Headphones, null, tint = glow.copy(alpha = 0.9f),
                modifier = Modifier.size(23.dp))
        }
        Row(Modifier.fillMaxWidth().height(37.dp).padding(horizontal = 9.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.VolumeUp, "Master volume", tint = secondary, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(13.dp))
            Slider(value = volume, onValueChange = onVolume, modifier = Modifier.weight(1f),
                colors = ambienceSlider(glow))
        }
    }
}

@Composable
private fun AuroraBackdrop(scene: String, glow: Color, light: Color, deep: Color, drift: Float,
                           modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        drawRect(Brush.verticalGradient(listOf(Color(0xFF11182A), deep, Color(0xFF07111B))))
        // Slow, translucent aurora light, drawn on-device (no bitmap assets, no network).
        val dx = (drift - 0.5f) * w * 0.19f
        drawCircle(Brush.radialGradient(
            listOf(light.copy(alpha = 0.35f), light.copy(alpha = 0.10f), Color.Transparent),
            center = Offset(w * 0.65f + dx, h * 0.27f), radius = w * 0.85f),
            radius = w * 0.85f, center = Offset(w * 0.65f + dx, h * 0.27f))
        drawCircle(Brush.radialGradient(
            listOf(glow.copy(alpha = 0.17f), Color.Transparent),
            center = Offset(w * 0.18f - dx, h * 0.63f), radius = w * 0.65f),
            radius = w * 0.65f, center = Offset(w * 0.18f - dx, h * 0.63f))
        repeat(4) { i ->
            val path = Path().apply {
                moveTo(-w * 0.19f, h * (0.16f + 0.055f * i))
                cubicTo(w * 0.31f, h * (0.05f + 0.03f * i) + dx * 0.18f,
                    w * 0.49f, h * (0.45f + 0.025f * i),
                    w * 1.15f, h * (0.10f + 0.065f * i))
            }
            drawPath(path, color = glow.copy(alpha = 0.055f + 0.01f * i),
                style = Stroke(width = (10 + i * 7).dp.toPx()))
        }
        // The environmental silhouette changes along with the preset.
        when (scene) {
            "Deep Forest" -> repeat(10) { i ->
                val x = w * (i / 9f)
                val base = h * (0.88f + (i % 3) * 0.02f)
                val height = h * (0.075f + (i % 4) * 0.022f)
                val p = Path().apply {
                    moveTo(x - w * 0.07f, base)
                    lineTo(x, base - height)
                    lineTo(x + w * 0.07f, base)
                    close()
                }
                drawPath(p, Color(0xFF081C23).copy(alpha = 0.5f))
            }
            "Night Shore" -> repeat(5) { i ->
                val y = h * (0.76f + i * 0.045f)
                val p = Path().apply {
                    moveTo(0f, y)
                    cubicTo(w * 0.32f, y - h * 0.02f, w * 0.65f, y + h * 0.025f, w, y)
                }
                drawPath(p, color = glow.copy(alpha = 0.09f), style = Stroke(1.5.dp.toPx()))
            }
            "Fireside" -> repeat(16) { i ->
                val x = ((i * 51 + 29) % 100) / 100f * w
                val y = (0.55f + ((i * 19) % 32) / 100f) * h - drift * h * 0.025f
                drawCircle(glow.copy(alpha = 0.12f + (i % 3) * 0.055f),
                    radius = (1.5f + i % 3).dp.toPx(), center = Offset(x, y))
            }
            else -> repeat(14) { i ->
                val x = ((i * 37 + 13) % 100) / 100f * w
                val y = ((i * 23 + 9) % 88) / 100f * h
                drawCircle(white.copy(alpha = 0.13f + (i % 3) * 0.055f),
                    radius = (0.6f + (i % 2) * 0.5f).dp.toPx(), center = Offset(x, y))
            }
        }
    }
}

@Composable
private fun SoundMap(sounds: List<SoundSource>, selectedId: Int, heading: Float,
                     tint: Color, playing: Boolean, breathe: Float,
                     onSelect: (Int) -> Unit, onMove: (Int, Float, Float) -> Unit) {
    BoxWithConstraints(Modifier.fillMaxWidth().aspectRatio(1.10f)) {
        val diameter = with(LocalDensity.current) { maxWidth.toPx() }
        val mid = diameter / 2f
        val radius = diameter * 0.365f
        Canvas(Modifier.fillMaxSize()) {
            val centerPoint = Offset(size.width / 2f, size.height / 2f)
            // Quiet, luminous range guides instead of a heavy map grid.
            listOf(0.30f, 0.66f, 1f).forEachIndexed { index, factor ->
                drawCircle(Color.White.copy(alpha = if (index == 2) 0.26f else 0.115f),
                    radius * factor, center = centerPoint,
                    style = Stroke(if (index == 2) 1.4.dp.toPx() else 1.dp.toPx()))
            }
            drawLine(Color.White.copy(alpha = 0.095f), Offset(centerPoint.x, centerPoint.y - radius),
                Offset(centerPoint.x, centerPoint.y + radius), 1.dp.toPx())
            drawLine(Color.White.copy(alpha = 0.07f), Offset(centerPoint.x - radius, centerPoint.y),
                Offset(centerPoint.x + radius, centerPoint.y), 1.dp.toPx())
            drawCircle(Brush.radialGradient(listOf(tint.copy(alpha = if (playing) 0.19f + breathe * 0.1f else 0.15f),
                Color.Transparent), center = centerPoint, radius = 52.dp.toPx()),
                radius = 52.dp.toPx(), center = centerPoint)
        }
        Text("FRONT", Modifier.align(Alignment.TopCenter).padding(top = 8.dp),
            fontSize = 9.sp, letterSpacing = 1.6.sp, color = Color.White.copy(alpha = 0.65f))
        Text("BACK", Modifier.align(Alignment.BottomCenter).padding(bottom = 7.dp),
            fontSize = 9.sp, letterSpacing = 1.6.sp, color = Color.White.copy(alpha = 0.57f))
        Box(Modifier.offset {
                IntOffset((mid - 22.dp.toPx()).roundToInt(),
                    (mid - 22.dp.toPx()).roundToInt())
            }.size(44.dp).clip(CircleShape)
            .background(Color(0xFF183038).copy(alpha = 0.95f))
            .border(1.5.dp, tint, CircleShape), contentAlignment = Alignment.Center) {
            Text("▲", color = tint, fontSize = 19.sp, modifier = Modifier.rotate(heading))
        }
        sounds.forEach { sound ->
            val chosen = sound.id == selectedId
            Box(Modifier.offset {
                IntOffset((mid + sound.x * radius - 24.dp.toPx()).roundToInt(),
                    (mid + sound.y * radius - 24.dp.toPx()).roundToInt())
            }.size(48.dp).clip(CircleShape)
                .background(if (sound.muted) Color(0xFF26333D) else
                    if (chosen) tint.copy(alpha = 0.30f) else Color(0xFF243748).copy(alpha = 0.94f))
                .border(if (chosen) 2.dp else 1.dp,
                    if (chosen) tint else Color.White.copy(alpha = 0.33f), CircleShape)
                .pointerInput(sound.id, radius) {
                    detectDragGestures(onDragStart = { onSelect(sound.id) }) { event, change ->
                        event.consume()
                        onMove(sound.id, change.x / radius, change.y / radius)
                    }
                }
                .semantics { contentDescription = "${sound.kind.title} sound position. Drag to move." }
                .clickable { onSelect(sound.id) }, contentAlignment = Alignment.Center) {
                Text(sound.kind.emoji, fontSize = 23.sp)
            }
        }
    }
}
