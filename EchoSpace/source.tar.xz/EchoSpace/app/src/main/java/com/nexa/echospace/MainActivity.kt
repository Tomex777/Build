@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.nexa.echospace

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nexa.echospace.audio.SpatialAudioService
import com.nexa.echospace.model.SceneStore
import com.nexa.echospace.model.Scenes
import com.nexa.echospace.model.SoundKind
import com.nexa.echospace.model.SoundScene
import com.nexa.echospace.model.SoundSource
import kotlinx.coroutines.delay
import kotlin.math.hypot
import kotlin.math.roundToInt

private val night = Color(0xFF080F18)
private val panel = Color(0xFF14222B)
private val accent = Color(0xFF9BE8CD)
private val white = Color(0xFFF2F7F5)
private val muted = Color(0xFF9CAEB4)

class MainActivity : ComponentActivity() {
    private var service by mutableStateOf<SpatialAudioService?>(null)
    private var bound = false
    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            service = (binder as? SpatialAudioService.LocalBinder)?.service()
        }
        override fun onServiceDisconnected(name: ComponentName?) { service = null }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(8, 15, 24)
        window.navigationBarColor = android.graphics.Color.rgb(8, 15, 24)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = accent, onPrimary = night,
                background = night, surface = panel, onSurface = white, onBackground = white
            )) {
                EchoSpaceScreen(service) { action ->
                    if (action == SpatialAudioService.ACTION_PLAY && Build.VERSION.SDK_INT >= 33 &&
                        checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                    ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 51)
                    val command = Intent(this, SpatialAudioService::class.java).setAction(action)
                    if (action == SpatialAudioService.ACTION_PLAY) startForegroundService(command)
                    else startService(command)
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        bound = bindService(Intent(this, SpatialAudioService::class.java), connection, Context.BIND_AUTO_CREATE)
    }
    override fun onStop() {
        if (bound) { unbindService(connection); bound = false }
        service = null
        super.onStop()
    }
}

@Composable
private fun EchoSpaceScreen(service: SpatialAudioService?, dispatch: (String) -> Unit) {
    val context = LocalContext.current
    val store = remember { SceneStore(context.applicationContext) }
    val restored = remember { store.restore() }
    var title by remember { mutableStateOf(restored?.first ?: Scenes.rainChamber.title) }
    var sources by remember { mutableStateOf(restored?.second ?: Scenes.rainChamber.sources) }
    var selectedId by remember { mutableIntStateOf(sources.firstOrNull()?.id ?: -1) }
    var volume by remember { mutableFloatStateOf(store.volume()) }
    var heading by remember { mutableFloatStateOf(store.heading()) }
    var isPlaying by remember { mutableStateOf(false) }
    var timerSeconds by remember { mutableLongStateOf(0L) }
    var timerOpen by remember { mutableStateOf(false) }
    var addOpen by remember { mutableStateOf(false) }
    var directionOpen by remember { mutableStateOf(false) }
    val selected = sources.firstOrNull { it.id == selectedId }

    LaunchedEffect(title, sources, volume, heading, service) {
        service?.updateAudio(title, sources, volume, heading)
        delay(350)
        store.save(title, sources, volume, heading)
    }
    LaunchedEffect(service) {
        while (true) {
            isPlaying = service?.isPlaying() == true
            timerSeconds = service?.remainingSeconds() ?: 0L
            delay(350)
        }
    }
    fun editSource(id: Int, block: (SoundSource) -> SoundSource) {
        sources = sources.map { if (it.id == id) block(it) else it }
    }
    fun setWorld(scene: SoundScene) {
        title = scene.title
        sources = scene.sources
        selectedId = sources.firstOrNull()?.id ?: -1
        heading = 0f
    }

    Scaffold(
        containerColor = night,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        bottomBar = {
            Column(
                Modifier.fillMaxWidth().background(night)
                    .navigationBarsPadding().padding(horizontal = 16.dp, vertical = 9.dp)
            ) {
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp))
                        .background(Color(0xFF1C3139)).padding(horizontal = 15.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = {
                            service?.updateAudio(title, sources, volume, heading)
                            dispatch(if (isPlaying) SpatialAudioService.ACTION_PAUSE else SpatialAudioService.ACTION_PLAY)
                            isPlaying = !isPlaying
                        },
                        enabled = service != null,
                        modifier = Modifier.size(52.dp).background(accent, CircleShape)
                    ) {
                        Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            if (isPlaying) "Pause" else "Play", tint = night, modifier = Modifier.size(30.dp))
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(title, color = white, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                            maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(if (isPlaying) "Playing" else "Ready", fontSize = 11.sp, color = muted)
                    }
                    Box {
                        IconButton(onClick = { timerOpen = true }) {
                            Icon(Icons.Default.Timer, "Sleep timer", tint = if (timerSeconds > 0) accent else muted)
                        }
                        DropdownMenu(expanded = timerOpen, onDismissRequest = { timerOpen = false }) {
                            listOf(0, 15, 30, 60).forEach { mins ->
                                DropdownMenuItem(
                                    text = { Text(if (mins == 0) "Timer off" else "$mins min") },
                                    onClick = { service?.setSleepTimer(mins); timerOpen = false }
                                )
                            }
                        }
                    }
                    Text(if (timerSeconds > 0) "${timerSeconds / 60}m" else "", color = accent,
                        fontSize = 11.sp)
                }
                Row(Modifier.fillMaxWidth().padding(horizontal = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.VolumeUp, "Volume", tint = muted, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(12.dp))
                    Slider(value = volume, onValueChange = { volume = it }, modifier = Modifier.weight(1f),
                        colors = SliderDefaults.colors(thumbColor = accent, activeTrackColor = accent,
                            inactiveTrackColor = Color(0xFF31545A)))
                }
            }
        }
    ) { pad ->
        Column(
            Modifier.fillMaxSize().padding(pad).statusBarsPadding()
                .background(Brush.verticalGradient(listOf(night, Color(0xFF10232C), night)))
                .verticalScroll(rememberScrollState()).padding(horizontal = 18.dp)
        ) {
            Spacer(Modifier.height(17.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("EchoSpace", fontSize = 24.sp, fontWeight = FontWeight.Bold,
                    letterSpacing = (-0.8).sp, color = white, modifier = Modifier.weight(1f))
                Icon(Icons.Default.Headphones, "Headphones recommended", tint = accent, modifier = Modifier.size(23.dp))
            }
            Spacer(Modifier.height(24.dp))
            Text("Environments", fontSize = 13.sp, color = muted, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                Scenes.presets.forEach { scene ->
                    val chosen = scene.title == title
                    Row(
                        Modifier.clip(RoundedCornerShape(17.dp))
                            .background(if (chosen) Color(0xFF264940) else panel)
                            .border(1.dp, if (chosen) accent else Color(0xFF293C44), RoundedCornerShape(17.dp))
                            .clickable { setWorld(scene) }
                            .padding(horizontal = 14.dp, vertical = 15.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(scene.emoji, fontSize = 23.sp)
                        Spacer(Modifier.width(8.dp))
                        Text(scene.title, color = if (chosen) white else muted,
                            fontSize = 13.sp, fontWeight = if (chosen) FontWeight.Bold else FontWeight.Medium)
                    }
                }
            }
            Spacer(Modifier.height(27.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(title, color = white, fontSize = 27.sp, fontWeight = FontWeight.SemiBold)
                    Text("Move sounds around you", color = muted, fontSize = 12.sp)
                }
                FilledTonalIconButton(onClick = { addOpen = true }, enabled = sources.size < 12,
                    colors = IconButtonDefaults.filledTonalIconButtonColors(containerColor = Color(0xFF234238))) {
                    Icon(Icons.Default.Add, "Add sound", tint = accent)
                }
            }
            Spacer(Modifier.height(16.dp))
            SoundMap(sources, selectedId, heading, isPlaying,
                onSelect = { selectedId = it },
                onMove = { id, dx, dy ->
                    editSource(id) { sound ->
                        val x = (sound.x + dx).coerceIn(-1f, 1f)
                        val y = (sound.y + dy).coerceIn(-1f, 1f)
                        val length = hypot(x, y)
                        if (length > 0.98f) sound.copy(x = x * 0.98f / length, y = y * 0.98f / length)
                        else sound.copy(x = x, y = y)
                    }
                }
            )
            Spacer(Modifier.height(13.dp))
            if (selected != null) {
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                    .background(panel).padding(start = 14.dp, end = 5.dp, top = 5.dp, bottom = 5.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Text("${selected.kind.emoji} ${selected.kind.title}", color = white,
                        fontSize = 13.sp, modifier = Modifier.widthIn(min = 75.dp, max = 115.dp))
                    Slider(value = selected.gain, onValueChange = { next ->
                        editSource(selected.id) { it.copy(gain = next) }
                    }, modifier = Modifier.weight(1f),
                        colors = SliderDefaults.colors(thumbColor = accent, activeTrackColor = accent,
                            inactiveTrackColor = Color(0xFF31545A)))
                    IconButton(onClick = {
                        editSource(selected.id) { it.copy(muted = !it.muted) }
                    }) {
                        Icon(if (selected.muted) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                            if (selected.muted) "Unmute ${selected.kind.title}" else "Mute ${selected.kind.title}",
                            tint = if (selected.muted) muted else accent, modifier = Modifier.size(19.dp))
                    }
                    IconButton(onClick = {
                        sources = sources.filterNot { it.id == selected.id }
                        selectedId = sources.firstOrNull()?.id ?: -1
                    }) { Icon(Icons.Default.DeleteOutline, "Remove ${selected.kind.title}",
                        tint = Color(0xFFE8ACAA), modifier = Modifier.size(19.dp)) }
                }
            }
            Spacer(Modifier.height(13.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("${sources.size} layers", color = muted, fontSize = 12.sp, modifier = Modifier.weight(1f))
                TextButton(onClick = { directionOpen = !directionOpen }) {
                    Text("Direction ${heading.roundToInt()}°", color = accent, fontSize = 12.sp)
                }
            }
            if (directionOpen) {
                Slider(value = heading, onValueChange = { heading = it }, valueRange = -180f..180f,
                    colors = SliderDefaults.colors(thumbColor = accent, activeTrackColor = accent,
                            inactiveTrackColor = Color(0xFF31545A)))
                TextButton(onClick = { heading = 0f }) { Text("Face forward", color = accent) }
            }
            service?.error()?.let { Text("Playback error: $it", color = Color(0xFFFF9C98)) }
            Spacer(Modifier.height(12.dp))
        }
    }

    if (addOpen) {
        ModalBottomSheet(onDismissRequest = { addOpen = false }, containerColor = panel) {
            Text("Add a sound", color = white, fontSize = 20.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp))
            Column(Modifier.heightIn(max = 450.dp).verticalScroll(rememberScrollState())) {
                SoundKind.entries.forEach { kind ->
                    Row(Modifier.fillMaxWidth().clickable {
                        val id = (sources.maxOfOrNull { it.id } ?: 0) + 1
                        sources = sources + SoundSource(id, kind, if (id % 2 == 0) 0.55f else -0.55f, -0.35f)
                        selectedId = id
                        addOpen = false
                    }.padding(horizontal = 22.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Text(kind.emoji, fontSize = 24.sp)
                        Spacer(Modifier.width(16.dp))
                        Text(kind.title, fontSize = 15.sp, color = white)
                    }
                }
            }
            Spacer(Modifier.navigationBarsPadding().height(6.dp))
        }
    }
}

@Composable
private fun SoundMap(
    sounds: List<SoundSource>, selectedId: Int, heading: Float, playing: Boolean,
    onSelect: (Int) -> Unit, onMove: (Int, Float, Float) -> Unit
) {
    BoxWithConstraints(
        Modifier.fillMaxWidth().aspectRatio(1f)
            .clip(RoundedCornerShape(28.dp))
            .background(Brush.radialGradient(listOf(Color(0xFF254349), Color(0xFF152831), Color(0xFF101D29))))
            .border(1.dp, Color(0xFF34525B), RoundedCornerShape(28.dp))
    ) {
        val diameter = with(LocalDensity.current) { maxWidth.toPx() }
        val mid = diameter / 2f
        val radius = diameter * 0.36f
        Canvas(Modifier.fillMaxSize()) {
            listOf(0.32f, 0.65f, 1f).forEach { scale ->
                drawCircle(Color(0xFF6C9EA2).copy(alpha = if (scale == 1f) 0.45f else 0.18f),
                    radius * scale, style = Stroke(if (scale == 1f) 1.5.dp.toPx() else 1.dp.toPx()))
            }
            drawLine(Color(0xFF5C8891).copy(alpha = 0.24f), Offset(center.x - radius, center.y),
                Offset(center.x + radius, center.y), 1.dp.toPx())
            drawLine(Color(0xFF5C8891).copy(alpha = 0.24f), Offset(center.x, center.y - radius),
                Offset(center.x, center.y + radius), 1.dp.toPx())
            drawCircle(accent.copy(alpha = if (playing) 0.16f else 0.08f), 37.dp.toPx())
        }
        Text("FRONT", Modifier.align(Alignment.TopCenter).padding(top = 12.dp),
            color = muted, fontSize = 10.sp, letterSpacing = 1.sp)
        Text("BACK", Modifier.align(Alignment.BottomCenter).padding(bottom = 12.dp),
            color = muted, fontSize = 10.sp, letterSpacing = 1.sp)
        Box(
            Modifier.offset { IntOffset((mid - 21.dp.toPx()).roundToInt(), (mid - 21.dp.toPx()).roundToInt()) }
                .size(42.dp).clip(CircleShape).background(Color(0xFF183B3B))
                .border(1.dp, accent, CircleShape), contentAlignment = Alignment.Center
        ) { Text("▲", color = accent, fontSize = 18.sp, modifier = Modifier.rotate(heading)) }
        sounds.forEach { sound ->
            val active = selectedId == sound.id
            Box(
                Modifier.offset {
                    IntOffset((mid + sound.x * radius - 22.dp.toPx()).roundToInt(),
                        (mid + sound.y * radius - 22.dp.toPx()).roundToInt())
                }.size(44.dp).clip(CircleShape)
                    .background(if (sound.muted) Color(0xFF2D3A41) else if (active) Color(0xFF346E66) else Color(0xFF254F55))
                    .border(if (active) 2.dp else 1.dp, if (active) accent else Color(0xFF699995), CircleShape)
                    .pointerInput(sound.id, radius) {
                        detectDragGestures(onDragStart = { onSelect(sound.id) }) { event, change ->
                            event.consume()
                            onMove(sound.id, change.x / radius, change.y / radius)
                        }
                    }
                    .clickable { onSelect(sound.id) }, contentAlignment = Alignment.Center
            ) { Text(sound.kind.emoji, fontSize = 23.sp) }
        }
    }
}
