# Environment artwork

Five photographs downloaded from Unsplash and bundled as optimized JPEGs so scene selection works offline. Used under the Unsplash License (https://unsplash.com/license). Do not offer these as standalone downloadable stock images.

- Rain Chamber — https://images.unsplash.com/photo-1751696924126-2697d62f6f49 (photo of a thunderstorm)
- Deep Forest — https://images.unsplash.com/photo-1562627952-f52a76c3c823 (misty woodland by Atanas Dzhingarov)
- Night Shore — https://images.unsplash.com/photo-1518837695005-2083093ee35b (ocean)
- Fireside — https://images.unsplash.com/photo-1464808646948-8f732deb6e4b (campfire by Luke Porter)
- Dream Drift — https://images.unsplash.com/photo-1592666452220-529326e2588e (purple starry night)

Photos licensed for free use; credits here for transparency. The visual design, cards, gradients and audio controls are part of the EchoSpace native Android codebase.
