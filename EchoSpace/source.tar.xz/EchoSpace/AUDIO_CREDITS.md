# EchoSpace v0.5: genuine recordings and measured binaural filtering

EchoSpace bundles source recordings under **Creative Commons Zero (CC0-1.0)**. The app downloads nothing while running. See `app/src/main/assets/recording_credits.json` for the exact creator, Freesound sound ID, file page, and embedded file for each sound. `tools/prepare_audio.py` validates licensing before any asset is bundled and aborts if a listing cannot be verified as CC0. The audio assets are trimmed downsampled mono excerpts of the credited recordings; they are not generated samples.

Audio sources: Freesound, Universitat Pompeu Fabra, https://freesound.org/ . The relevant sound pages can be found under `RECORDINGS` in `tools/prepare_audio.py`.

**Binaural filters:** measured KEMAR dummy-head HRIRs, Gardner, W. G., and Martin, K. D. (1995), *HRTF Measurements of a KEMAR Dummy-Head Microphone*, MIT Media Lab Perceptual Computing Technical Report No. 280. Filter coefficients were published by Aristotel Digenis in `jhonmark/mit-hrtf-lib` (MIT-licensed source). `tools/prepare_audio.py` packages measured horizontal-plane impulse responses at 0°, 90°, 180°, interpolated in real-time for the listener's manual heading. This is a generic HRTF, not personalized or elevation-positioned, and does not use head tracking.

DSP architecture: audio is decoded offline during the build to 22.05kHz mono PCM. The phone loads it locally on an audio worker. `SpatialSynth` interpolates/resamples at 44.1kHz, applies distance attenuation and MIT KEMAR FIR per sound, blends scenes, and allows a user-disableable generative *Living* arrangement to slowly evolve environmental balance. It continues to provide procedural fallback for missing/corrupt recordings but the release CI fails if any credited asset is absent.

The *Living* feature changes gains/event density of recorded sources only and doesn't synthesize or invent recordings. This is an initial HRTF implementation: room acoustics, physics-based occlusion, head tracking, individualized measurements, device-latency tests and real-headphone listening still require additional engineering. Do not describe this implementation as complete 6DoF spatial audio.
