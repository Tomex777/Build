package com.nexa.echospace.tools

import com.nexa.echospace.audio.SpatialSynth
import com.nexa.echospace.model.Scenes
import java.io.File
import java.io.DataOutputStream
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.sqrt

/** Optional desktop audio smoke test. Usage: java -cp ... RenderPreviewKt output.wav forest */
fun main(args: Array<String>) {
    require(args.isNotEmpty()) { "Output WAV file required" }
    val scene = when(args.getOrNull(1)) {
        "forest" -> Scenes.forest
        "shore" -> Scenes.shore
        "fire" -> Scenes.fireside
        "dream" -> Scenes.drift
        else -> Scenes.rainChamber
    }
    val seconds = 12
    val rate = 44_100
    val pcmBytes = rate * seconds * 4
    val data = ByteBuffer.allocate(pcmBytes).order(ByteOrder.LITTLE_ENDIAN)
    val synth = SpatialSynth(rate)
    val block = ShortArray(1024)
    var sum = 0.0
    var peak = 0
    var diff = 0.0
    repeat(rate * seconds / (block.size / 2)) {
        synth.renderInto(block, scene.sources, 0.80f)
        for (i in block.indices step 2) {
            sum += block[i].toDouble() * block[i].toDouble() + block[i + 1].toDouble() * block[i + 1]
            peak = maxOf(peak, abs(block[i].toInt()), abs(block[i + 1].toInt()))
            diff += abs(block[i] - block[i + 1]).toDouble()
            data.putShort(block[i]); data.putShort(block[i + 1])
        }
    }
    File(args[0]).outputStream().buffered().use { f ->
        fun le16(v: Int) { f.write(v and 0xff); f.write((v ushr 8) and 0xff) }
        fun le32(v: Int) { repeat(4) { i -> f.write((v ushr (8*i)) and 0xff) } }
        f.write("RIFF".toByteArray()); le32(data.position() + 36)
        f.write("WAVEfmt ".toByteArray()); le32(16); le16(1); le16(2)
        le32(rate); le32(rate * 4); le16(4); le16(16)
        f.write("data".toByteArray()); le32(data.position())
        f.write(data.array(), 0, data.position())
    }
    println("${scene.title}: RMS=${sqrt(sum / (data.position() / 2)) / 32768}, peak=${peak / 32768.0}, stereoDiff=$diff")
}
