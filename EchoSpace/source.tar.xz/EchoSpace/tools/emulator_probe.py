"""Minimal Android UIAutomator smoke-test helper for the real EchoSpace APK."""
from __future__ import annotations
import re
import subprocess
import sys
import xml.etree.ElementTree as ET


def adb(*args: str) -> str:
    return subprocess.check_output(["adb", *args], text=True, stderr=subprocess.STDOUT)


def snapshot() -> ET.Element:
    adb("shell", "uiautomator", "dump", "/sdcard/window.xml")
    xml = adb("shell", "cat", "/sdcard/window.xml")
    return ET.fromstring(xml[xml.index("<?xml"):])


def match(node: ET.Element, kind: str, value: str) -> bool:
    field = {"text": "text", "desc": "content-desc"}[kind]
    return node.attrib.get(field) == value


def run(action: str, kind: str, value: str) -> None:
    root = snapshot()
    matches = [node for node in root.iter("node") if match(node, kind, value)]
    if not matches:
        found = [(n.attrib.get("text"), n.attrib.get("content-desc"))
                 for n in root.iter("node") if n.attrib.get("text") or n.attrib.get("content-desc")]
        raise RuntimeError(f"UI element missing: {kind}={value!r}\nVisible: {found[:90]}")
    if action == "assert":
        print(f"PASS {kind}={value}")
        return
    bounds = matches[0].attrib["bounds"]
    x1, y1, x2, y2 = map(int, re.findall(r"\d+", bounds))
    adb("shell", "input", "tap", str((x1+x2)//2), str((y1+y2)//2))
    print(f"TAPPED {kind}={value} at {((x1+x2)//2, (y1+y2)//2)}")


if __name__ == "__main__":
    if len(sys.argv) != 4 or sys.argv[1] not in ("tap", "assert") or sys.argv[2] not in ("text", "desc"):
        sys.exit("Usage: emulator_probe.py {tap|assert} {text|desc} VALUE")
    run(*sys.argv[1:])
