package com.night.mirrorchess.data

import android.content.Context
import com.night.mirrorchess.chess.Pgn
import com.night.mirrorchess.mirror.MirrorProfile
import com.night.mirrorchess.mirror.MirrorProfileBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class MirrorRepository(context: Context) {
    private val file = File(context.filesDir, "mirror_profile.dat")

    fun load(): MirrorProfile? = runCatching {
        if (!file.isFile) null else MirrorProfile.fromStorageText(file.readText())
    }.getOrNull()

    fun save(profile: MirrorProfile) {
        runCatching { file.writeText(profile.toStorageText()) }
    }

    suspend fun importPgn(text: String, playerName: String): Result<MirrorProfile> = withContext(Dispatchers.Default) {
        runCatching {
            val parsed = Pgn.parseMany(text)
            require(parsed.games.isNotEmpty()) { parsed.errors.firstOrNull() ?: "No chess games were found in that PGN." }
            val imported = MirrorProfileBuilder.build(parsed.games, playerName)
            require(imported.movesLearned > 0) {
                if (playerName.isBlank()) "No moves could be learned from the imported games."
                else "No games matched '$playerName'. Check the exact Chess.com/Lichess username in the PGN."
            }
            val merged = (load() ?: MirrorProfile.empty()).merge(imported)
            save(merged)
            merged
        }
    }

    fun delete() { file.delete() }
}
