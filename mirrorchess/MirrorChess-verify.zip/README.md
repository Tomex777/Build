# Mirror Chess 1.0

A native Android chess-learning app built with Kotlin + Jetpack Compose. Mirror Chess is designed around human-like move prediction: play a Maia-strength opponent, compare your choices with human move probabilities, or import your own PGNs to create a lightweight **Mirror Me** personalization layer.

## Android baseline

- package: `com.night.mirrorchess`
- minSdk: **36**
- targetSdk: **36**
- compileSdk: **36**
- AGP: **9.1.1**
- Kotlin / Compose compiler plugin: **2.2.10**
- Compose BOM: **2026.02.01**
- Java toolchain: **17**

## Included product flows

### Play
- Maia 1200 / 1800 / 2200 opponents
- Play White, Black, or random
- Tap or drag pieces
- Legal move and last-move highlighting
- Castling, en passant, promotion chooser
- Checkmate, stalemate, threefold repetition, fifty-move and conservative insufficient-material handling
- Full-turn undo, board flip, resign and rematch
- Human move-comparison coach and Maia W/D/L output when the real model is installed
- Active-game recovery after process death
- Recent game archive, position-by-position review and PGN export

### Mirror Me
- Import normal Chess.com/Lichess PGN files
- Optional username matching to learn only your side
- Stores exact position -> move memories
- Builds simple capture/check/castling/center/piece-use tendencies
- Re-ranks Maia's human move distribution toward those habits
- Stays in app-private storage

Mirror Me is intentionally described as a **personalization layer**, not as full neural-network retraining on the phone.

### Local Maia model
The app works without the neural model by falling back to its built-in preview opponent. In **Settings**, the user can:

1. Download Maia-3 5M directly in-app, or
2. Import the ONNX file manually.

The app verifies the expected SHA-256 before installing it. Once installed, chess inference is local.

Model file: `maia3-5m.fp16.onnx`

Expected SHA-256:
`ca22fc3031975932e693f9758149302efc177749165443ed52de828add8864fa`

See `MODEL_SETUP.md` and `THIRD_PARTY_NOTICES.md`.

## Open in Android Studio

1. Extract the ZIP.
2. Open the `MirrorChess` folder in Android Studio.
3. Let Gradle sync.
4. Use an Android 16 / API 36 device or emulator.
5. Run `app`.
6. Open **Settings** inside the app to install Maia when wanted.

## Validation performed in this source snapshot

The Android UI cannot be Gradle-built in the packaging environment because it has no Android SDK and outbound Gradle/Maven resolution is blocked. The platform-independent chess/model code was compiled with Kotlin and smoke-tested directly.

Validated:
- starting-position perft: **20 / 400 / 8,902 / 197,281**
- checkmate detection
- FEN round-trip
- PGN multi-game parsing
- Mirror profile build + serialization round-trip
- conservative insufficient-material behavior
- Maia move-vocabulary encoding including Black-to-move normalization

See `BUILD_STATUS.md` for the exact limitation.
