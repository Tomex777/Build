# Build status — Mirror Chess 1.0

## Source status

The v1.0 source tree is packaged as a complete Android Studio project with Gradle wrapper files.

The platform-independent core compiles and its smoke suite passes:

- perft depth 1: 20
- perft depth 2: 400
- perft depth 3: 8,902
- perft depth 4: 197,281
- Fool's Mate checkmate detection
- FEN serialize/restore
- multi-game PGN import
- Mirror profile build/serialize/restore
- Maia 4,352-move vocabulary indexing sanity check

## Android build limitation of this packaging environment

A final `assembleDebug` could not be executed here because:

1. no Android SDK is installed in this execution environment; and
2. Gradle cannot download its distribution or dependencies because outbound DNS/network access is blocked.

An attempted wrapper run stops at `UnknownHostException: services.gradle.org` before project compilation begins.

This means the ZIP is a source-complete Android Studio project, but **not an APK-certified build** from this environment. Android Studio on a normal networked development machine is the final compile gate.

## Model

The Maia ONNX binary is intentionally not bundled in the ZIP. The app can download/import it at runtime and verifies its SHA-256 before installation. Without it, the preview engine remains usable.
