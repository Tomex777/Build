package com.night.mirrorchess.ui

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.night.mirrorchess.data.AppSettings
import com.night.mirrorchess.data.BoardPalette
import com.night.mirrorchess.data.StoredGame
import com.night.mirrorchess.viewmodel.GameViewModel
import com.night.mirrorchess.viewmodel.OpponentProfile
import com.night.mirrorchess.viewmodel.PlayerColorChoice
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class RootRoute { PLAY, MIRROR, SETTINGS, GAME }

@Composable
fun MirrorChessApp(viewModel: GameViewModel) {
    val context = LocalContext.current
    val ui = viewModel.uiState
    var routeName by rememberSaveable { mutableStateOf(RootRoute.PLAY.name) }
    var pgnUsername by rememberSaveable { mutableStateOf("") }
    var pendingExport by remember { mutableStateOf("") }
    val route = runCatching { RootRoute.valueOf(routeName) }.getOrDefault(RootRoute.PLAY)

    val pgnImport = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) viewModel.importMirrorPgn(uri, pgnUsername)
    }
    val modelImport = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) viewModel.importModel(uri)
    }
    val pgnExport = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/x-chess-pgn")) { uri ->
        if (uri != null && pendingExport.isNotBlank()) {
            runCatching { context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(pendingExport) } }
        }
        pendingExport = ""
    }

    fun exportCurrent() {
        pendingExport = viewModel.exportCurrentPgn()
        val stamp = SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(Date())
        pgnExport.launch("MirrorChess-$stamp.pgn")
    }

    if (route == RootRoute.GAME) {
        BackHandler {
            if (ui.reviewing) viewModel.exitReview()
            routeName = RootRoute.PLAY.name
        }
        GameScreen(
            viewModel = viewModel,
            onExit = {
                if (viewModel.uiState.reviewing) viewModel.exitReview()
                routeName = RootRoute.PLAY.name
            },
            onExport = ::exportCurrent,
        )
        return
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                RootNavItem("Play", route == RootRoute.PLAY, { routeName = RootRoute.PLAY.name }) { color -> PlayGlyph(color, Modifier.size(20.dp)) }
                RootNavItem("Mirror", route == RootRoute.MIRROR, { routeName = RootRoute.MIRROR.name }) { color -> MirrorGlyph(color, Modifier.size(20.dp)) }
                RootNavItem("Settings", route == RootRoute.SETTINGS, { routeName = RootRoute.SETTINGS.name }) { color -> SettingsGlyph(color, Modifier.size(20.dp)) }
            }
        },
    ) { padding ->
        when (route) {
            RootRoute.PLAY -> PlayHome(
                viewModel = viewModel,
                modifier = Modifier.padding(padding),
                onGameStarted = { routeName = RootRoute.GAME.name },
                onResume = { viewModel.resumeActiveGame(); routeName = RootRoute.GAME.name },
                onReview = { game -> viewModel.reviewGame(game); routeName = RootRoute.GAME.name },
            )
            RootRoute.MIRROR -> MirrorHome(
                viewModel = viewModel,
                username = pgnUsername,
                onUsername = { pgnUsername = it },
                onImport = { pgnImport.launch(arrayOf("application/x-chess-pgn", "text/plain", "application/octet-stream")) },
                modifier = Modifier.padding(padding),
            )
            RootRoute.SETTINGS -> SettingsHome(
                viewModel = viewModel,
                onImportModel = { modelImport.launch(arrayOf("application/octet-stream", "*/*")) },
                modifier = Modifier.padding(padding),
            )
            RootRoute.GAME -> Unit
        }
    }
}

@Composable
private fun RowScope.RootNavItem(label: String, selected: Boolean, onClick: () -> Unit, icon: @Composable (Color) -> Unit) {
    NavigationBarItem(
        selected = selected,
        onClick = onClick,
        icon = { icon(if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant) },
        label = { Text(label, style = MaterialTheme.typography.labelSmall) },
    )
}

@Composable
private fun PageHeader(kicker: String, title: String, body: String? = null) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Text(kicker, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
        Text(title, style = MaterialTheme.typography.displaySmall)
        body?.let { Text(it, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
}

@Composable
private fun PlayHome(
    viewModel: GameViewModel,
    onGameStarted: () -> Unit,
    onResume: () -> Unit,
    onReview: (StoredGame) -> Unit,
    modifier: Modifier = Modifier,
) {
    val ui = viewModel.uiState
    var opponentName by rememberSaveable { mutableStateOf(OpponentProfile.CLUB.name) }
    var colorName by rememberSaveable { mutableStateOf(PlayerColorChoice.WHITE.name) }
    val selectedOpponent = runCatching { OpponentProfile.valueOf(opponentName) }.getOrDefault(OpponentProfile.CLUB)
    val selectedColor = runCatching { PlayerColorChoice.valueOf(colorName) }.getOrDefault(PlayerColorChoice.WHITE)

    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        PageHeader(
            kicker = if (ui.modelInstalled) "MAIA READY · OFFLINE" else "PREVIEW ENGINE",
            title = "Play a human, not a machine.",
            body = "Choose a human-strength Maia opponent, then compare your decisions with what players near your rating usually choose.",
        )

        ui.resumableGame?.takeIf { it.moves.isNotEmpty() }?.let {
            Surface(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 4.dp).clickable(onClick = onResume),
                color = MaterialTheme.colorScheme.primaryContainer,
                shape = RoundedCornerShape(14.dp),
            ) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("RESUME GAME", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                        Text("${it.moves.size} plies saved", style = MaterialTheme.typography.titleMedium)
                    }
                    Text("Continue", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                }
            }
        }

        SectionTitle("OPPONENT")
        Column(Modifier.padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            OpponentProfile.entries.forEach { profile ->
                val enabled = !profile.mirror || ui.mirrorProfile != null
                ChoiceRow(
                    title = profile.label,
                    subtitle = if (profile.mirror && ui.mirrorProfile == null) "Import PGNs in Mirror first" else profile.description,
                    trailing = if (profile.mirror) (ui.mirrorProfile?.movesLearned?.let { "$it moves" } ?: "LOCKED") else profile.elo.toString(),
                    selected = profile == selectedOpponent,
                    enabled = enabled,
                    onClick = { opponentName = profile.name },
                )
            }
        }

        SectionTitle("PLAY AS")
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PlayerColorChoice.entries.forEach { choice ->
                val selected = choice == selectedColor
                OutlinedButton(
                    onClick = { colorName = choice.name },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface),
                ) { Text(choice.name.lowercase().replaceFirstChar { it.uppercase() }) }
            }
        }

        Button(
            onClick = { viewModel.startGame(selectedColor, selectedOpponent); onGameStarted() },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 16.dp).height(52.dp),
        ) { Text("Start game") }

        if (!ui.modelInstalled) {
            Text(
                "The app is playable now with its preview engine. Install Maia-3 in Settings for the real local human-move model.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 18.dp),
            )
        }

        if (ui.recentGames.isNotEmpty()) {
            SectionTitle("RECENT GAMES")
            Column(Modifier.padding(horizontal = 18.dp, vertical = 2.dp)) {
                ui.recentGames.take(12).forEach { game -> RecentGameRow(game) { onReview(game) } }
            }
        }
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
private fun RecentGameRow(game: StoredGame, onClick: () -> Unit) {
    val date = SimpleDateFormat("MMM d · HH:mm", Locale.US).format(Date(game.endedAt ?: game.startedAt))
    Row(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Surface(modifier = Modifier.size(34.dp), color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(9.dp)) {
            Box(contentAlignment = Alignment.Center) { Text(game.result, style = MaterialTheme.typography.labelSmall) }
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(runCatching { OpponentProfile.valueOf(game.opponentId).label }.getOrDefault(game.opponentId), style = MaterialTheme.typography.titleMedium)
            Text("$date · ${game.moves.size} plies", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Text("Review", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
    }
}

@Composable
private fun MirrorHome(
    viewModel: GameViewModel,
    username: String,
    onUsername: (String) -> Unit,
    onImport: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val ui = viewModel.uiState
    val profile = ui.mirrorProfile
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        PageHeader(
            kicker = "MIRROR ME",
            title = "Turn your games into an opponent.",
            body = "Import Chess.com or Lichess PGNs. Mirror remembers positions you actually played and bends Maia's move distribution toward your own habits.",
        )
        OutlinedTextField(
            value = username,
            onValueChange = onUsername,
            label = { Text("Username in the PGN") },
            supportingText = { Text("Leave blank to learn both sides from every imported game.") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp),
        )
        Button(onClick = onImport, modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp).height(50.dp)) { Text("Import PGN file") }
        ui.mirrorImportMessage?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(horizontal = 18.dp)) }

        if (profile != null) {
            SectionTitle("YOUR PROFILE")
            Column(Modifier.padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    MetricCard("GAMES", profile.gamesImported.toString(), Modifier.weight(1f))
                    MetricCard("MOVES", profile.movesLearned.toString(), Modifier.weight(1f))
                    MetricCard("POSITIONS", profile.positionMemory.size.toString(), Modifier.weight(1f))
                }
                StyleMeter("Captures", profile.captureRate)
                StyleMeter("Checks", profile.checkRate)
                StyleMeter("Castling", profile.castleRate)
                StyleMeter("Center moves", profile.centerRate)
                Text(
                    "Mirror Me is a personalization layer, not a claim that the neural network has retrained itself on your phone. Exact remembered positions receive the strongest boost; broader style habits adjust Maia elsewhere.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                TextButton(onClick = viewModel::deleteMirrorProfile) { Text("Delete Mirror profile") }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun SettingsHome(viewModel: GameViewModel, onImportModel: () -> Unit, modifier: Modifier = Modifier) {
    val ui = viewModel.uiState
    val settings = ui.settings
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        PageHeader(
            kicker = "SETTINGS",
            title = "Keep the intelligence on-device.",
            body = "Maia-3 is downloaded once, checksum-verified, and stored privately by the app. After that, model inference does not need the network.",
        )

        SectionTitle("MAIA-3 MODEL")
        Surface(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp),
            shape = RoundedCornerShape(14.dp),
            color = MaterialTheme.colorScheme.surface,
        ) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(8.dp).background(if (ui.modelInstalled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant, CircleShape))
                    Spacer(Modifier.width(8.dp))
                    Column(Modifier.weight(1f)) {
                        Text(if (ui.modelInstalled) "Maia-3 5M installed" else "Preview engine active", style = MaterialTheme.typography.titleMedium)
                        Text(if (ui.modelInstalled) "Verified local ONNX model" else "Install the ~11 MB model for real Maia predictions", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                ui.modelDownloadProgress?.let { StyleMeter("Download", it) }
                ui.modelMessage?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (!ui.modelInstalled) Button(onClick = viewModel::downloadModel, modifier = Modifier.weight(1f)) { Text("Download") }
                    OutlinedButton(onClick = onImportModel, modifier = Modifier.weight(1f)) { Text("Import ONNX") }
                    if (ui.modelInstalled) OutlinedButton(onClick = viewModel::deleteModel) { Text("Remove") }
                }
            }
        }

        SectionTitle("YOUR RATING")
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(1200, 1800, 2200).forEach { elo ->
                OutlinedButton(
                    onClick = { viewModel.updateSettings(settings.copy(playerElo = elo)) },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = if (settings.playerElo == elo) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface),
                ) { Text(elo.toString()) }
            }
        }

        SectionTitle("BOARD")
        Column(Modifier.padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            BoardPalette.entries.forEach { palette ->
                ChoiceRow(
                    title = palette.name.lowercase().replaceFirstChar { it.uppercase() },
                    subtitle = "Board color preset",
                    trailing = if (settings.boardPalette == palette) "ACTIVE" else "",
                    selected = settings.boardPalette == palette,
                    onClick = { viewModel.updateSettings(settings.copy(boardPalette = palette)) },
                )
            }
        }

        SectionTitle("GAME")
        SettingsToggle("Legal move markers", settings.showLegalMoves) { viewModel.updateSettings(settings.copy(showLegalMoves = it)) }
        SettingsToggle("Board coordinates", settings.showCoordinates) { viewModel.updateSettings(settings.copy(showCoordinates = it)) }
        SettingsToggle("Move coach", settings.coachEnabled) { viewModel.updateSettings(settings.copy(coachEnabled = it)) }
        SettingsToggle("Haptics", settings.haptics) { viewModel.updateSettings(settings.copy(haptics = it)) }

        SectionTitle("PRIVACY & LICENSES")
        Text(
            "Imported PGNs, your Mirror profile, active games, and archives stay in app-private storage. Android cloud backup is disabled. The app shell is clean-room code; the optional Maia-3 model has its own AGPL-3.0 licensing obligations—see THIRD_PARTY_NOTICES.md in the project.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 18.dp),
        )
        Spacer(Modifier.height(28.dp))
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(start = 18.dp, end = 18.dp, top = 20.dp, bottom = 8.dp))
}

@Composable
private fun ChoiceRow(
    title: String,
    subtitle: String,
    trailing: String,
    selected: Boolean,
    enabled: Boolean = true,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth().height(58.dp).clickable(enabled = enabled, onClick = onClick).padding(horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(9.dp).background(if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline, CircleShape).alpha(if (enabled) 1f else .35f))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f).alpha(if (enabled) 1f else .45f)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Text(trailing, style = MaterialTheme.typography.labelSmall, color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun MetricCard(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(modifier = modifier, shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.surface) {
        Column(Modifier.padding(12.dp)) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value, style = MaterialTheme.typography.titleLarge)
        }
    }
}

@Composable
private fun StyleMeter(label: String, value: Float) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(Modifier.fillMaxWidth()) {
            Text(label, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
            Text("${(value.coerceIn(0f, 1f) * 100).toInt()}%", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Box(Modifier.fillMaxWidth().height(5.dp).background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(3.dp))) {
            Box(Modifier.fillMaxWidth(value.coerceIn(0f, 1f)).height(5.dp).background(MaterialTheme.colorScheme.primary, RoundedCornerShape(3.dp)))
        }
    }
}

@Composable
private fun SettingsToggle(label: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 18.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChecked)
    }
}
