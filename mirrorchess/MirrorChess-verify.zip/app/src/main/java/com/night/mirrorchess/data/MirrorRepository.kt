package com.night.mirrorchess.data

import android.content.Context
import com.night.mirrorchess.chess.Pgn
import com.night.mirrorchess.mirror.MirrorProfile
import com.night.mirrorchess.mirror.MirrorProfileBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class MirrorRepository(context: Context) {
    private val file = File(context.filesDir, "mirror_profile.dat")

    fun load(): MirrorProfile? = runCatching {
        if (!file.isFile) null else MirrorProfile.fromStorageText(file.readText())
    }.getOrNull()

    suspend fun importPgn(text: String, playerName: String): Result<MirrorProfile> = withContext(Dispatchers.Default) {
        runCatching {
            val parsed = Pgn.parseMany(text)
            require(parsed.games.isNotEmpty()) { parsed.errors.firstOrNull() ?: "No chess games were found in that PGN." }
            val profile = MirrorProfileBuilder.build(parsed.games, playerName)
            require(profile.movesLearned > 0) {
                if (playerName.isBlank()) "No moves could be learned from the imported games."
                else "No games matched '$playerName'. Check the exact Chess.com/Lichess username in the PGN."
            }
            file.writeText(profile.toStorageText())
            profile
        }
    }

    fun delete() { file.delete() }
}
