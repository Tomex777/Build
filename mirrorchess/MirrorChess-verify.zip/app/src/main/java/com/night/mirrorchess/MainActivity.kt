package com.night.mirrorchess

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.night.mirrorchess.ui.MirrorChessApp
import com.night.mirrorchess.ui.MirrorChessTheme
import com.night.mirrorchess.viewmodel.GameViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MirrorChessTheme {
                val vm: GameViewModel = viewModel()
                MirrorChessApp(vm)
            }
        }
    }
}
