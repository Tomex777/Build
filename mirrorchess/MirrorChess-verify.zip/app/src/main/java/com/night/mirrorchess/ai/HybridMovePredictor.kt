package com.night.mirrorchess.ai

import android.content.Context
import com.night.mirrorchess.chess.GameState

class HybridMovePredictor(context: Context) : MovePredictor, AutoCloseable {
    private val real = Maia3OnnxMovePredictor(context.applicationContext)
    private val fallback = HeuristicMovePredictor()

    override val isRealModel: Boolean get() = real.modelExists()

    override suspend fun predict(
        state: GameState,
        selfElo: Int,
        opponentElo: Int,
        limit: Int,
    ): PredictionBundle {
        if (!real.modelExists()) return fallback.predict(state, selfElo, opponentElo, limit)
        return runCatching { real.predict(state, selfElo, opponentElo, limit) }
            .getOrElse { fallback.predict(state, selfElo, opponentElo, limit) }
    }

    fun reloadModel() = real.reload()

    override fun close() = real.close()
}
