package com.night.mirrorchess.mirror

import com.night.mirrorchess.ai.MovePrediction
import com.night.mirrorchess.chess.ChessRules
import com.night.mirrorchess.chess.GameState
import com.night.mirrorchess.chess.Move
import com.night.mirrorchess.chess.PgnGame
import com.night.mirrorchess.chess.PieceType
import com.night.mirrorchess.chess.Side
import com.night.mirrorchess.chess.fileOf
import com.night.mirrorchess.chess.gameStateFromFen
import com.night.mirrorchess.chess.rankOf
import com.night.mirrorchess.chess.san
import java.nio.charset.StandardCharsets
import java.util.Base64
import kotlin.math.max

/** Lightweight personal style layer. It does not retrain Maia weights; it personalizes Maia's distribution. */
data class MirrorProfile(
    val playerName: String,
    val gamesImported: Int,
    val movesLearned: Int,
    val positionMemory: Map<String, Map<String, Int>>,
    val captureRate: Float,
    val checkRate: Float,
    val castleRate: Float,
    val centerRate: Float,
    val pieceRates: Map<PieceType, Float>,
) {
    fun memoryCount(state: GameState, move: Move): Int =
        positionMemory[ChessRules.repetitionKey(state)]?.get(move.uci()) ?: 0

    fun personalize(state: GameState, candidates: List<MovePrediction>): List<MovePrediction> {
        if (candidates.isEmpty()) return emptyList()
        val memory = positionMemory[ChessRules.repetitionKey(state)].orEmpty()
        val maxMemory = memory.values.maxOrNull()?.coerceAtLeast(1) ?: 1
        val weighted = candidates.map { candidate ->
            val move = candidate.move
            val piece = state.board[move.from]
            val capture = move.isEnPassant || state.board[move.to] != null
            val after = runCatching { ChessRules.applyLegalMove(state, move) }.getOrNull()
            val check = after?.let { ChessRules.isInCheck(it, it.turn) } == true
            val center = fileOf(move.to) in 2..5 && rankOf(move.to) in 2..5
            val style = 1f +
                similarity(capture, captureRate) * 0.22f +
                similarity(check, checkRate) * 0.18f +
                similarity(move.isCastle, castleRate) * 0.22f +
                similarity(center, centerRate) * 0.12f +
                (piece?.type?.let { pieceRates[it] } ?: 0f) * 0.20f
            val memoryBoost = 1f + 2.6f * ((memory[move.uci()] ?: 0).toFloat() / maxMemory)
            candidate to (candidate.probability * style * memoryBoost)
        }
        val total = weighted.sumOf { it.second.toDouble() }.toFloat().coerceAtLeast(1e-7f)
        return weighted
            .map { (candidate, weight) ->
                candidate.copy(
                    probability = weight / total,
                    explanation = if ((memory[candidate.move.uci()] ?: 0) > 0) {
                        "You have played this move from the same position before."
                    } else {
                        "Maia move probability adjusted toward your imported playing tendencies."
                    },
                )
            }
            .sortedByDescending { it.probability }
    }

    fun toStorageText(): String = buildString {
        appendLine("MIRROR1")
        appendLine("name=${enc(playerName)}")
        appendLine("games=$gamesImported")
        appendLine("moves=$movesLearned")
        appendLine("capture=$captureRate")
        appendLine("check=$checkRate")
        appendLine("castle=$castleRate")
        appendLine("center=$centerRate")
        appendLine("pieces=" + PieceType.entries.joinToString(",") { "${it.name}:${pieceRates[it] ?: 0f}" })
        positionMemory.forEach { (key, counts) ->
            append("P|").append(enc(key)).append('|')
            append(counts.entries.joinToString(",") { "${it.key}:${it.value}" })
            appendLine()
        }
    }

    companion object {
        fun fromStorageText(text: String): MirrorProfile? = runCatching {
            val lines = text.lineSequence().toList()
            require(lines.firstOrNull() == "MIRROR1")
            val fields = lines.drop(1).filter { !it.startsWith("P|") && '=' in it }.associate {
                it.substringBefore('=') to it.substringAfter('=')
            }
            val pieces = fields["pieces"].orEmpty().split(',').mapNotNull { item ->
                val name = item.substringBefore(':', "")
                val value = item.substringAfter(':', "").toFloatOrNull()
                PieceType.entries.firstOrNull { it.name == name }?.let { type -> value?.let { type to it } }
            }.toMap()
            val memory = linkedMapOf<String, Map<String, Int>>()
            lines.filter { it.startsWith("P|") }.forEach { line ->
                val parts = line.split('|', limit = 3)
                if (parts.size == 3) {
                    val counts = parts[2].split(',').mapNotNull { token ->
                        val uci = token.substringBefore(':', "")
                        val count = token.substringAfter(':', "").toIntOrNull()
                        if (uci.isNotBlank() && count != null) uci to count else null
                    }.toMap()
                    memory[dec(parts[1])] = counts
                }
            }
            MirrorProfile(
                playerName = dec(fields.getValue("name")),
                gamesImported = fields.getValue("games").toInt(),
                movesLearned = fields.getValue("moves").toInt(),
                positionMemory = memory,
                captureRate = fields.getValue("capture").toFloat(),
                checkRate = fields.getValue("check").toFloat(),
                castleRate = fields.getValue("castle").toFloat(),
                centerRate = fields.getValue("center").toFloat(),
                pieceRates = pieces,
            )
        }.getOrNull()

        private fun enc(value: String): String = Base64.getUrlEncoder().withoutPadding().encodeToString(value.toByteArray(StandardCharsets.UTF_8))
        private fun dec(value: String): String = String(Base64.getUrlDecoder().decode(value), StandardCharsets.UTF_8)
        private fun similarity(flag: Boolean, rate: Float): Float = if (flag) rate else 1f - rate
    }
}

object MirrorProfileBuilder {
    fun build(games: List<PgnGame>, playerName: String): MirrorProfile {
        val normalizedName = playerName.trim()
        val memory = linkedMapOf<String, MutableMap<String, Int>>()
        val pieceCounts = PieceType.entries.associateWith { 0 }.toMutableMap()
        var learned = 0
        var captures = 0
        var checks = 0
        var castles = 0
        var centers = 0
        var matchedGames = 0

        games.forEach { game ->
            val side = when {
                normalizedName.isBlank() -> null
                game.white.equals(normalizedName, ignoreCase = true) -> Side.WHITE
                game.black.equals(normalizedName, ignoreCase = true) -> Side.BLACK
                else -> return@forEach
            }
            matchedGames++
            var state = game.headers["FEN"]?.let(::gameStateFromFen) ?: GameState.initial()
            game.moves.forEach { move ->
                val movingSide = state.turn
                if (side == null || side == movingSide) {
                    val piece = state.board[move.from]
                    val key = ChessRules.repetitionKey(state)
                    val counts = memory.getOrPut(key) { linkedMapOf() }
                    counts[move.uci()] = (counts[move.uci()] ?: 0) + 1
                    learned++
                    if (move.isEnPassant || state.board[move.to] != null) captures++
                    if (move.isCastle) castles++
                    if (fileOf(move.to) in 2..5 && rankOf(move.to) in 2..5) centers++
                    piece?.let { pieceCounts[it.type] = (pieceCounts[it.type] ?: 0) + 1 }
                    val after = ChessRules.applyLegalMove(state, move)
                    if (ChessRules.isInCheck(after, after.turn)) checks++
                }
                state = ChessRules.applyLegalMove(state, move)
            }
        }

        val denominator = max(1, learned).toFloat()
        return MirrorProfile(
            playerName = normalizedName.ifBlank { "Imported player" },
            gamesImported = matchedGames,
            movesLearned = learned,
            positionMemory = memory.mapValues { it.value.toMap() },
            captureRate = captures / denominator,
            checkRate = checks / denominator,
            castleRate = castles / denominator,
            centerRate = centers / denominator,
            pieceRates = pieceCounts.mapValues { it.value / denominator },
        )
    }
}
