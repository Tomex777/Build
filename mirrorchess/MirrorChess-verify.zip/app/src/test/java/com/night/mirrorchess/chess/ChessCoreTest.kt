package com.night.mirrorchess.chess

import com.night.mirrorchess.ai.Maia3Encoding
import com.night.mirrorchess.mirror.MirrorProfile
import com.night.mirrorchess.mirror.MirrorProfileBuilder
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ChessCoreTest {
    @Test
    fun startingPositionMatchesKnownPerftCounts() {
        val initial = GameState.initial()
        assertEquals(20L, perft(initial, 1))
        assertEquals(400L, perft(initial, 2))
        assertEquals(8_902L, perft(initial, 3))
        assertEquals(197_281L, perft(initial, 4))
    }

    @Test
    fun detectsCheckmateAndCoreDrawConditions() {
        val mate = play("f2f3", "e7e5", "g2g4", "d8h4")
        assertEquals(GameResult.CHECKMATE, ChessRules.status(mate).result)

        val bareKings = requireNotNull(gameStateFromFen("8/8/8/8/8/5k2/8/7K w - - 0 1"))
        assertEquals(GameResult.DRAW_INSUFFICIENT, ChessRules.status(bareKings).result)

        val fiftyMove = requireNotNull(gameStateFromFen("8/8/8/8/8/5k2/8/R6K w - - 100 1"))
        assertEquals(GameResult.DRAW_50_MOVE, ChessRules.status(fiftyMove).result)

        var repeated = GameState.initial()
        val history = mutableListOf(repeated)
        listOf("g1f3", "g8f6", "f3g1", "f6g8", "g1f3", "g8f6", "f3g1", "f6g8").forEach { uci ->
            repeated = applyUci(repeated, uci)
            history += repeated
        }
        val repetitions = history.count { ChessRules.repetitionKey(it) == ChessRules.repetitionKey(repeated) }
        assertEquals(3, repetitions)
        assertEquals(GameResult.DRAW_THREEFOLD, ChessRules.status(repeated, repetitions).result)
    }

    @Test
    fun appliesCastlingEnPassantAndPromotionCorrectly() {
        val castled = play("e2e4", "e7e5", "g1f3", "b8c6", "f1c4", "g8f6", "e1g1")
        assertEquals(Piece(Side.WHITE, PieceType.KING), castled.board[square("g1")])
        assertEquals(Piece(Side.WHITE, PieceType.ROOK), castled.board[square("f1")])
        assertNull(castled.board[square("e1")])
        assertNull(castled.board[square("h1")])

        val enPassant = play("e2e4", "a7a6", "e4e5", "d7d5", "e5d6")
        assertEquals(Piece(Side.WHITE, PieceType.PAWN), enPassant.board[square("d6")])
        assertNull(enPassant.board[square("d5")])

        val promotionStart = requireNotNull(gameStateFromFen("7k/P7/8/8/8/8/8/7K w - - 0 1"))
        val promoted = applyUci(promotionStart, "a7a8n")
        assertEquals(Piece(Side.WHITE, PieceType.KNIGHT), promoted.board[square("a8")])
    }

    @Test
    fun fenRoundTripPreservesAPlayedPosition() {
        val fen = play("e2e4", "c7c5", "g1f3", "d7d6").toFen()
        assertEquals(fen, gameStateFromFen(fen)?.toFen())
    }

    @Test
    fun pgnImportsMultipleGamesCommentsVariationsAndSemicolonLines() {
        val input = """
            [Event "One"]
            [White "Alice"]
            [Black "Bob"]
            [Result "1-0"]

            1. e4 {main line} e5 (1... c5) 2. Nf3 Nc6 3. Bb5 a6 1-0

            [Event "Two"]
            [White "Bob"]
            [Black "Alice"]
            [Result "1/2-1/2"]

            1. d4 ; this comment must end at the newline
            1... d5 2. c4 e6 1/2-1/2
        """.trimIndent()

        val parsed = Pgn.parseMany(input)
        assertTrue(parsed.errors.joinToString(), parsed.errors.isEmpty())
        assertEquals(2, parsed.games.size)
        assertEquals(listOf("d4", "d5", "c4", "e6"), parsed.games[1].sanMoves)
    }

    @Test
    fun mirrorProfileBuildsPersonalizesAndRoundTrips() {
        val parsed = Pgn.parseMany(
            """
                [Event "Mirror"]
                [White "Alice"]
                [Black "Bob"]
                [Result "1-0"]

                1. e4 e5 2. Nf3 Nc6 3. Bb5 a6 1-0
            """.trimIndent(),
        )
        val profile = MirrorProfileBuilder.build(parsed.games, "Alice")
        assertEquals(1, profile.gamesImported)
        assertEquals(3, profile.movesLearned)

        val restored = MirrorProfile.fromStorageText(profile.toStorageText())
        assertNotNull(restored)
        assertEquals(profile.positionMemory, restored?.positionMemory)
        assertEquals(profile.movesLearned, restored?.movesLearned)
    }

    @Test
    fun maiaVocabularyRoundTripsWhiteBlackAndPromotions() {
        val positions = listOf(
            GameState.initial(),
            play("e2e4"),
            requireNotNull(gameStateFromFen("7k/P7/8/8/8/8/8/7K w - - 0 1")),
            requireNotNull(gameStateFromFen("7k/8/8/8/8/8/p7/7K b - - 0 1")),
        )

        positions.forEach { state ->
            ChessRules.legalMoves(state).forEach { move ->
                val encoded = Maia3Encoding.vocabularyIndex(move, state.turn)
                assertNotNull("No Maia index for ${move.uci()}", encoded)
                assertTrue(encoded in 0 until Maia3Encoding.MOVE_VOCAB_SIZE)
                assertEquals(move.uci(), Maia3Encoding.uciAt(requireNotNull(encoded), state.turn))
            }
        }
    }

    @Test
    fun rejectsIllegalMoves() {
        val initial = GameState.initial()
        assertNull(ChessRules.findLegalMove(initial, square("e2"), square("e5")))
        assertFalse(ChessRules.isInCheck(initial, Side.WHITE))
        assertFalse(ChessRules.isInCheck(initial, Side.BLACK))
    }

    private fun perft(state: GameState, depth: Int): Long {
        if (depth == 0) return 1L
        return ChessRules.legalMoves(state).sumOf { move ->
            perft(ChessRules.applyLegalMove(state, move), depth - 1)
        }
    }

    private fun play(vararg moves: String): GameState = moves.fold(GameState.initial()) { state, uci ->
        applyUci(state, uci)
    }

    private fun applyUci(state: GameState, uci: String): GameState {
        val promotion = uci.getOrNull(4)?.let { char ->
            when (char.lowercaseChar()) {
                'q' -> PieceType.QUEEN
                'r' -> PieceType.ROOK
                'b' -> PieceType.BISHOP
                'n' -> PieceType.KNIGHT
                else -> null
            }
        }
        val move = ChessRules.findLegalMove(
            state,
            square(uci.substring(0, 2)),
            square(uci.substring(2, 4)),
            promotion,
        )
        return ChessRules.applyLegalMove(state, requireNotNull(move) { "Illegal test move: $uci" })
    }

    private fun square(name: String): Int = requireNotNull(squareFromName(name))
}
