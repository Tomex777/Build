# Changelog

## 1.0.0

- Added Play / Mirror / Settings product shell.
- Added White, Black and random-color game starts.
- Added proper promotion chooser.
- Added resign, rematch, full-turn undo and finished-game review.
- Added PGN parsing/export and FEN serialization.
- Added threefold, fifty-move and conservative insufficient-material draw handling.
- Added active-game recovery and recent-game archive.
- Added in-app Maia model download/import/delete with SHA-256 verification.
- Changed Maia loader to prefer app-private model storage while retaining development asset support.
- Added Mirror Me PGN personalization profile and exact-position memory.
- Added board palettes, legal-move/coordinate/coach/haptic settings.
- Added custom launcher vector and privacy hardening (`allowBackup=false`, HTTPS-only cleartext policy).
- Kept Android baseline at minSdk/targetSdk/compileSdk 36.

## 0.2.0

- Custom vector chess pieces.
- Tightened game layout and coach panel.
- Maia opponent presets and learning comparison UI.

## 0.1.0

- Initial playable chessboard, rules engine and Maia inference boundary.
