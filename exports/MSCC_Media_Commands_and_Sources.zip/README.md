# MSCC Media Commands and Sources

This is a source-only selection from Tomex777/Build, branch mscc-azure.
It includes Anime, Manga, Movie, TV, Books and Android command handlers;
matching source adapters and providers; shared flow helpers; and source-related tests.

Import the mscc/ paths into an existing MSCC checkout if you want to reuse them.
These modules rely on MSCC command context, storage, WhatsApp transport,
Node.js dependencies and configuration. It is NOT a standalone bot.
No active session data, private keys, or production credentials are bundled.
See MANIFEST.json for exact source commit and file inventory.
