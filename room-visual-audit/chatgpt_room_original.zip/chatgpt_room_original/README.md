# ChatGPT Room Benchmark — Independent Build

A procedural Three.js room created independently for comparison against the same benchmark prompt given to DeepSeek.

## Run
Serve the folder over HTTP/HTTPS (ES modules cannot be reliably loaded from `file://` on many browsers):

```bash
python -m http.server 8080
```

Then open `http://localhost:8080`.

The project fetches Three.js r160 and its official addons from jsDelivr at runtime.

## Controls
- Drag: orbit
- Pinch / wheel: zoom
- Tap the desk lamp: toggle it
- R: reset camera
- L: toggle desk lamp

## Visual intent
A compact modern bedroom/study with a real architectural shell, recessed window, curtains, detailed bed, desk, task chair, wall shelf, books, plants, lighting, radiator, rug, wall art and small construction details. Geometry is procedural; no downloaded 3D assets or image textures are used.

## Verification
- JavaScript syntax checked with Node.
- Relative project references checked.
- Not visually executed here because the runtime environment cannot fetch the CDN-hosted Three.js modules.
